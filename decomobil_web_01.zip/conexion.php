<?php
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "login_dc";

    $conexion = new mysqli($host, $username, $password, $database);

    //^ Verificar la conexion
    if ($conexion->connect_error) {
        die("Error de conexión:" . $conexion->connect_error);
    }

    //? Esta comentado para que no muestre el mensaje a cada rato XDDDD
    //echo("<script>alert('Conectado a la DB pibe');</script>");
?>