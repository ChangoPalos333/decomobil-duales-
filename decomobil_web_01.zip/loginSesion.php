<?php
    include("conexion.php");

    $email = $_POST["email"];
    $password = $_POST["password"];

    //?Esta vaina busca al ususario por mail
    $stmt = $conexion->prepare("SELECT *FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if(password_verify($password, $user['password'])) {

            //? Crear sesion... (?) No se w yo le estoy haciendo caso a la porquerIA

            session_start();
            $_SESSION['id'] = $user['id'];
            $_SESSION['name'] = $user['name'];

            header("Location: home.php");
            exit();
        } else {
            header("Location: login.php?msg=IncorrectPassword");
            echo("<script>alert('Contraseña incorrecta');</script>");
            exit();
        }
    } else {
        header("Location: login.php?msg=UserNotFound");
        echo("<script>alert('Usuario no encontrado');</script>");
        exit();
    }

    $conexion->close();
?>