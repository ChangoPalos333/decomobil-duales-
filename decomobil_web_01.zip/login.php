<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión || Decomobil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="ll">
        <div class="lt">
            <div>
                <h1>DECOMOBIL</h1>
            </div>
            <div>
                <h3>Soporte interno</h3>
                <h1>Gestion de tickets sin complicaciones.</h1>
                <h3>Reporta problemas, asigna soluciones y da seguimiento --- todo en un solo lugar.</h3>
            </div>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr);">
                <div>
                    <h2>100%</h2>
                    <h5>En tu navegador</h5>
                </div>
                <div>
                    <h2>3</h2>
                    <h5>Niveles de acceso</h5>
                </div>
                <div>

                    <h2>♾️</h2>
                    <h5>Historial</h5>
                </div>
            </div>
        </div>
        <div class="lg">
            <form action="loginSesion.php" method="POST">
                <h2>Iniciar sesión</h2>
                <input type="email" name="email" placeholder="Correo" required>
                <input type="password" name="password" placeholder="Contraseña" required>
                <button type="submit">Iniciar sesión</button>
            </form>
        </div>
    </div>
    <!--? Esto es para los mensajes de error -->
    <?php
        if(isset($_GET['msg']) && $_GET['msg'] === 'IncorrectPassword') {
            echo("<script>alert('Contraseña incorrecta');</script>");
        }
        if(isset($_GET['msg']) && $_GET['msg'] === 'UserNotFound') {
            echo("<script>alert('Usuario no encontrado');</script>");
        }
    ?>
</body>
</html>