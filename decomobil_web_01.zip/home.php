<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Decomobil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="hl">
        <H1>DECOMOBIL</H1>
    </div>
</body>
</html>