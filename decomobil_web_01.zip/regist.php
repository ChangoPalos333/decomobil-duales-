<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de prueba</title>
    <link rel="stylesheet" href="style.css">
    </head>
<body>
    <div class="login">
        <div class="loginCaja">
            <h2>Registrar Nuevo Usuario</h2>
            <h4>Esto es solo para el rol de administrador</h4>
            <form action="insertar.php" method="post">
                <input type="text" name="name" placeholder="Nombre" required>
                <input type="email" name="email" placeholder="Correo" required>
                <input type="password" name="password" placeholder="Contraseña" required>
                <!--?  Aqui se agregan los campos de rol y departamento -->
                <div id="slector">
                    <div>
                        <label for="">Asignar un rol</label>
                        <select name="role" required>
                            <option value="admin">Administrador</option>
                            <option value="agent">Agente</option>
                            <option value="user">Usuario</option>
                        </select>
                    </div>
                    <div>
                        <label for="">Asignar un Departamento</label>
                        <select name="dept" required>
                            <option value="administracion">Administracion</option>
                            <option value="produccion">Produccion</option>
                            <option value="ventas">Ventas</option>
                            <option value="logistica">Logistica</option>
                            <option value="finanzas">Finanzas</option>
                            <option value="rrhh">RRHH</option>
                            <option value="direccion">Direccion</option>
                        </select>
                    </div>
                </div>
                <button type="submit">Registrar</button>
                <a href="login.php">¿Ya tienes una cuenta? Inicia sesión aquí</a>
        </div>
        </form>
    </div>

    <?php
        if(isset($_GET['msg']) && $_GET['msg'] === 'EmailExists') {
            echo("<script>alert('El correo ya esta registrado');</script>");
        }
        if (isset($_GET['msg']) && $_GET['msg'] === 'Ok') {
            echo("<scrip>alert('Registro exitoso');</scrip>");
        }
    ?>
</body>
</html>