
<?php 
//? Esto enlaza la conexion con la DB
include("conexion.php");

//? Aqui se declaran ps las variables que se van a insertar en la DB
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$role = $_POST['role'];
$dept = $_POST['dept']; 

//! Esta linea encripta la contraseña w
//& Al chile no se ni pa k pero ahi ta :b
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

//? Eta' vaina lo que hace es verificar si el registro ya esta en la base de datos
//? El select busca el correo
$stmt = $conexion->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

//?Comprueba si ya hay filas con este correo
if($result->num_rows > 0){
    //? Esta mielda te redirecciona al login por k no jalo tu mmd
    header("Location: /decomobil_web/regist.php?msg=EmailExists");
} else {
    //? Inserta los datos
    $stmt = $conexion->prepare("INSERT INTO users (name, email, password, role, dept) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $passwordHash, $role, $dept);

    if ($stmt->execute()) {
        //?  Esta mielda te lleva a la pagina de usuarios cuando si carga bien
        header("Location: /decomobil_web/users.php?msg=Ok");
        exit();
    } else {
        echo ("<script>alert('Error: " . $stmt->error . "');</script>");
    }
}
    echo("<img src"."='https://i.pinimg.com/736x/b3/72/1c/b3721ccce6c01382105854aba935b2f4.jpg''>");
    $conexion->close();
?>