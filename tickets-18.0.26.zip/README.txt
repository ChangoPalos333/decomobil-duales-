================================================================================
                        DECOMOBIL - SISTEMA DE TICKETS
                          Sistema de Gestión de Soporte
================================================================================

DESCRIPCIÓN GENERAL
================================================================================
Decomobil es una aplicación web moderna para la gestión de tickets de soporte
técnico. Permite a los usuarios crear tickets, hacer seguimiento de problemas
y comunicarse en tiempo real con agentes de soporte. Los agentes y 
administradores pueden gestionar, asignar y resolver tickets de forma eficiente.

La aplicación está desarrollada con:
- Frontend: HTML5, CSS3, JavaScript (sin frameworks externos)
- Backend: PHP 7.4+ con MySQL/MariaDB
- Base de datos: MySQL 5.7+ (XAMPP)
- Autenticación: JWT-style tokens en sessionStorage


CARACTERÍSTICAS PRINCIPALES
================================================================================

1. AUTENTICACIÓN Y SESIONES
   - Login/Logout seguro con verificación de contraseña
   - Identificador de usuario: Primera letra del nombre + Apellido
   - Tokens de sesión en sessionStorage
   - 3 roles: usuario, agente, administrador
   - Permisos diferenciados por rol

2. GESTIÓN DE TICKETS
   - Crear nuevos tickets con descripción, prioridad y categoría
   - Estados: Abierto, En Progreso, En Revisión, Pendiente, Resuelto
   - Prioridades: Crítica, Alta, Media, Baja
   - Asignación a agentes de soporte
   - Búsqueda y filtrado por estado, prioridad, categoría, departamento
   - Eliminación de tickets (soft delete)

3. CHAT EN TIEMPO REAL
   - Sistema de comentarios para cada ticket usando long polling
   - Historial completo de mensajes
   - Notificaciones push cuando hay nuevos mensajes
   - Integración con sistema de actividad

4. NOTIFICACIONES
   - Notificaciones en navegador (Desktop Notifications)
   - Notificaciones de noticias y chat
   - Panel de noticias para administradores
   - Sistema global de alertas

5. PANEL DE ADMINISTRACIÓN
   - Vista de todos los tickets
   - Tabs para filtrar por estado
   - Cambio de estado y asignación rápida
   - Métricas y estadísticas
   - Gestión de usuarios

6. PÁGINAS INFORMATIVAS
   - Inicio: Dashboard con noticias y tickets
   - Nosotros: Política de calidad de la empresa
   - Organigrama: Estructura organizacional
   - Usuarios: Gestión de usuarios (solo admin)
   - Métricas: Análisis de tickets (solo admin)


ESTRUCTURA DE CARPETAS
================================================================================

decomobil/
├── README.txt                    # Este archivo
├── rc/                           # Recursos (iconos, imágenes)
│   └── decomobil_logo.ico
├── styles/
│   └── style.css                 # CSS global (tema, componentes, responsive)
├── scripts/
│   ├── global-notifications.js   # Sistema global de notificaciones
│   ├── notification-manager.js   # Gestor centralizado de notificaciones
│   ├── script.js                 # Script general (no usado actualmente)
│   ├── service-worker.js         # Service Worker para PWA
│   └── sw.js                     # Alternativa de Service Worker
├── src/
│   ├── admin.php                 # Panel de administración de tickets
│   ├── company.php               # Página de información de la empresa
│   ├── home.php                  # Página de inicio (dashboard)
│   ├── login.php                 # Página de login
│   ├── metrics.php               # Panel de métricas (admin)
│   ├── new.php                   # Formulario de crear ticket
│   ├── org.php                   # Organigrama de la empresa
│   └── users.php                 # Gestión de usuarios (admin)
└── xampp_project/
    ├── api/
    │   ├── auth.php              # API de autenticación
    │   ├── auth_helpers.php       # Funciones de autenticación
    │   ├── activity.php           # API de actividad y comentarios
    │   ├── chat.php               # API de chat en tiempo real
    │   ├── news.php               # API de noticias
    │   ├── tickets.php            # API de tickets (CRUD)
    │   └── users.php              # API de usuarios (CRUD)
    ├── config/
    │   └── database.php           # Configuración de BD y funciones helper
    ├── database/
    │   └── decomobil.sql          # Esquema de base de datos
    └── js/
        └── api.js                 # Cliente JavaScript para la API


FLUJO DE FUNCIONAMIENTO
================================================================================

1. LOGIN
   - Usuario ingresa credenciales (identificador + contraseña)
   - auth.php valida contra la BD
   - Se genera token de sesión
   - Token se almacena en sessionStorage
   - Usuario es redirigido a home.php

2. CREAR TICKET
   - Usuario relléna formulario en new.php
   - JavaScript envía POST a /api/tickets.php
   - Ticket se almacena en BD
   - Se genera entrada de actividad
   - Usuario ve confirmación

3. VER TICKETS
   - Usuarios ven solo sus tickets creados
   - Agentes/Admin ven tickets asignados
   - Búsqueda y filtrado con apiFetch()
   - Tabla renderizada dinámicamente

4. CHAT EN TIEMPO REAL
   - Usuario/Agente abre chat del ticket
   - TicketChat.open() inicia el panel lateral
   - Long polling cada 250ms a /api/chat.php
   - Nuevos mensajes se renderizan en tiempo real
   - Notificaciones push si hay nuevos mensajes

5. ADMINISTRACIÓN
   - Solo agentes/admins pueden acceder a admin.php
   - Vista de todos los tickets con tabs
   - Cambio de estado: apiFetch() PUT a /api/tickets.php
   - Asignación: apiFetch() PUT a /api/tickets.php
   - Eliminación: apiFetch() DELETE a /api/tickets.php

6. CIERRE DE SESIÓN
   - Usuario click en "Salir"
   - sessionStorage se limpia
   - Redirige a login.php


TECNOLOGÍAS Y PATRONES
================================================================================

FRONTEND:
- HTML5 semántico con variables CSS personalizadas
- CSS3 con grid, flexbox, animaciones
- JavaScript vanilla (ES6+) con fetch API
- Session Storage para autenticación
- Long polling para chat en tiempo real

BACKEND:
- PHP 7.4+ procedural
- PDO para conexión a BD (parametrizado, previene SQL injection)
- Patrón Singleton para la conexión a BD
- RESTful API (GET, POST, PUT, DELETE)
- JWT-style tokens

BD:
- MySQL 5.7+ con InnoDB
- Tablas: users, tickets, ticket_activity, news
- Índices para optimizar búsquedas
- Soft delete para tickets

SEGURIDAD:
- Hashing de contraseñas con bcrypt
- Tokens en headers Authorization
- Prepared statements en PDO
- Validación de permisos por rol
- CORS implícito (mismo dominio)


CONFIGURACIÓN INICIAL
================================================================================

1. XAMPP
   - Descarga XAMPP desde apache.org
   - Instala con PHP 7.4+
   - Inicia Apache y MySQL

2. BASE DE DATOS
   - Copia el archivo decomobil.sql
   - Accede a phpMyAdmin (http://localhost/phpmyadmin)
   - Crea base de datos: decomobil_db
   - Importa decomobil.sql
   - Verifica tablas: users, tickets, ticket_activity, news

3. CÓDIGO
   - Descarga el proyecto en c:\xampp\htdocs\decomobil
   - Verifica la estructura de carpetas
   - No requiere instalación de dependencias (vanilla JS)

4. USUARIO DE PRUEBA
   - Nombre: Admin User
   - Email: admin@decomobil.com
   - Identificador: AUser (A + User)
   - Contraseña: (ver decomobil.sql)
   - Rol: admin

5. ACCESO
   - Abre http://localhost/decomobil/src/login.php
   - Ingresa credenciales de prueba
   - Deberías ver el dashboard


CONEXIÓN A BASE DE DATOS
================================================================================

Archivo: xampp_project/config/database.php

Configuración:
- Host: localhost
- Base de datos: decomobil_db
- Usuario: root
- Contraseña: (vacía en XAMPP por defecto)

Para cambiar:
1. Edita database.php
2. Modifica las constantes DB_HOST, DB_NAME, DB_USER, DB_PASS
3. Reinicia Apache

Ejemplo:
  define('DB_HOST', 'servidor.com');
  define('DB_NAME', 'produccion_bd');
  define('DB_USER', 'usuario_bd');
  define('DB_PASS', 'contraseña_fuerte');


API ENDPOINTS
================================================================================

AUTENTICACIÓN:
  POST   /api/auth.php?action=login     - Iniciar sesión
  GET    /api/auth.php?action=logout    - Cerrar sesión
  GET    /api/auth.php?action=session   - Verificar sesión

TICKETS:
  GET    /api/tickets.php               - Listar tickets
  GET    /api/tickets.php?id=TK-001     - Obtener ticket
  GET    /api/tickets.php?stats=1       - Estadísticas
  POST   /api/tickets.php               - Crear ticket
  PUT    /api/tickets.php               - Actualizar ticket
  DELETE /api/tickets.php?id=TK-001     - Eliminar ticket

USUARIOS:
  GET    /api/users.php                 - Listar usuarios
  GET    /api/users.php?id=1            - Obtener usuario
  POST   /api/users.php                 - Crear usuario
  PUT    /api/users.php                 - Actualizar usuario
  DELETE /api/users.php?id=1            - Eliminar usuario

CHAT:
  GET    /api/chat.php?ticket_id=TK-001 - Nuevos mensajes (long polling)
  POST   /api/chat.php                  - Enviar mensaje

ACTIVIDAD:
  GET    /api/activity.php?ticket_id=... - Obtener historial
  POST   /api/activity.php              - Registrar actividad

NOTICIAS:
  GET    /api/news.php                  - Listar noticias
  POST   /api/news.php                  - Crear noticia (admin)
  PUT    /api/news.php                  - Actualizar noticia (admin)
  DELETE /api/news.php?id=1             - Eliminar noticia (admin)


DESARROLLO Y MODIFICACIONES
================================================================================

AGREGAR NUEVA PÁGINA:
1. Crea archivo en /src/nuevapagina.php
2. Copia estructura HTML de login.php o home.php
3. Incluye validación de sesión
4. Agrega enlace en navbar de las otras páginas

MODIFICAR API:
1. Edita el archivo en /api/
2. Sigue el patrón de routing switch/case
3. Usa getDB() para conexión
4. Usa jsonResponse() para respuestas
5. Prueba con Postman o curl

AGREGAR NUEVO CAMPO A TICKETS:
1. Altera tabla en BD: ALTER TABLE tickets ADD COLUMN nuevo_campo ...
2. Actualiza INSERT/UPDATE en /api/tickets.php
3. Actualiza SELECT en getTickets()
4. Actualiza normalizeTicket() en admin.php si es necesario
5. Agrega campo en formulario /src/new.php si es entrada

AGREGAR NUEVO ESTADO O PRIORIDAD:
1. Edita la lista en /api/tickets.php
2. Agrega opción en <select> de /src/new.php
3. Agrega badge CSS en /styles/style.css si es necesario
4. Prueba filtrado en admin.php


SOLUCIÓN DE PROBLEMAS
================================================================================

"Usuario no encontrado"
- Verifica que el usuario exista en BD (users)
- Confirma el identificador (primera letra nombre + apellido)
- Revisa que la contraseña sea correcta

"Error de conexión a BD"
- Verifica que MySQL esté corriendo en XAMPP
- Confirma credenciales en config/database.php
- Prueba conexión en phpmyadmin

"Permisos insuficientes"
- Verifica el rol del usuario en tabla users (admin, agent, user)
- Algunos endpoints requieren role=agent o role=admin
- Algunas páginas redirigen si el rol no es válido

"Notificaciones no funcionan"
- Verifica permisos de notificaciones en navegador
- Mira la consola (F12 > Console) para errores
- Service Worker debe estar registrado

"Chat no carga mensajes"
- Verifica que /api/chat.php sea accesible
- Revisa auth token en sessionStorage
- Mira consola para errores de fetch


MEJORAS FUTURAS
================================================================================

1. Autenticación:
   - OAuth2 con Google/Microsoft
   - Two-factor authentication
   - Recuperación de contraseña por email

2. Features:
   - Archivos adjuntos en tickets
   - Notificaciones por email
   - Reportes en PDF
   - Integración con calendario
   - Videoconferencia en chat

3. Rendimiento:
   - WebSockets en lugar de long polling
   - Caché de BD
   - Compresión de assets
   - CDN para archivos estáticos

4. UI/UX:
   - Dashboard más interactivo
   - Temas oscuro/claro
   - Modo móvil mejorado
   - Accesibilidad WCAG 2.1

5. Datos:
   - Exportación de reportes
   - Análisis predictivo
   - Integración con CRM
   - API pública para terceros


RECURSOS
================================================================================

Documentación oficial:
- PHP: https://www.php.net/manual/
- MySQL: https://dev.mysql.com/doc/
- JavaScript: https://developer.mozilla.org/

Herramientas recomendadas:
- IDE: VS Code con extensión PHP Intelephense
- API testing: Postman o Insomnia
- BD: phpMyAdmin o DBeaver
- Versionamiento: Git

Estándares seguidos:
- PSR-12: Guía de estilo PHP
- ECMAScript 6+
- REST API conventions


CONTACTO Y SOPORTE
================================================================================

Este proyecto fue desarrollado con ayuda de los alumnos DUALES:Edwin Perez y
Carlos Acosta.

Para consultas:

1. Revisa este README.txt para entender la arquitectura
2. Lee los comentarios en el código fuente
3. Consulta la base de datos (decomobil.sql)
4. Prueba los endpoints con Postman


HISTORIAL DE CAMBIOS
================================================================================

Versión 17.6.26 (Actual)
- Sistema de autenticación completo
- CRUD de tickets funcional
- Chat en tiempo real con long polling
- Panel de administración
- Notificaciones en navegador
- Gestión de usuarios
- Métricas y estadísticas
- Interfaz responsive

Todos los archivos incluyen comentarios detallados explicando:
- Qué hace cada sección
- Cómo funciona el código
- Parámetros y valores esperados
- Consideraciones de seguridad


LICENCIA
================================================================================

Este proyecto es propietario de Decomobil.
Uso únicamente para fines internos de la empresa.
Prohibida la distribución sin autorización.


================================================================================
                        FIN DEL DOCUMENTO
================================================================================
