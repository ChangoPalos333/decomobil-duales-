<?php
/**
 * ═══════════════════════════════════════════════════════════════════
 * DECOMOBIL - Funciones Helper de Autenticación
 * ═══════════════════════════════════════════════════════════════════
 * 
 * Este archivo contiene funciones reutilizables para:
 * - Extraer y validar tokens de autorización
 * - Obtener el usuario actual autenticado
 * - Validar que un usuario tenga permisos sobre un recurso
 * - Verificar acceso a tickets específicos
 * 
 * FLUJO DE AUTENTICACIÓN:
 * 1. Cliente envía token en header: "Authorization: Bearer TOKEN"
 * 2. getBearerToken() extrae el token
 * 3. getCurrentUser() valida el token en la BD
 * 4. Se devuelve el objeto user con permisos
 * 5. requireAuth() fuerza autenticación (termina si falla)
 * 
 * SEGURIDAD:
 * - Los tokens expiran automáticamente
 * - Se verifica que el usuario esté activo
 * - Las contraseñas se descartan en la respuesta
 * - Se valida que los usuarios solo vean sus recursos
 */

require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * FUNCIÓN: getBearerToken()
 * Extrae el token de autenticación del header Authorization
 * 
 * BÚSQUEDA EN MÚLTIPLES UBICACIONES:
 * - Header Authorization directo: "Authorization: Bearer TOKEN"
 * - apache_request_headers() si no está en $_SERVER
 * - REDIRECT_HTTP_AUTHORIZATION para Apache rewrite
 * 
 * RETORNA: string con el token, o null si no hay
 * 
 * EJEMPLO:
 * - Request header: "Authorization: Bearer abc123xyz..."
 * - Retorna: "abc123xyz..."
 */
function getBearerToken() {
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    if (!$authHeader && function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        if (!empty($headers['Authorization'])) {
            $authHeader = $headers['Authorization'];
        } elseif (!empty($headers['authorization'])) {
            $authHeader = $headers['authorization'];
        }
    }

    if (!$authHeader) {
        $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    }

    if (strpos($authHeader, 'Bearer ') === 0) {
        return substr($authHeader, 7);
    }

    return null;
}

/**
 * FUNCIÓN: getCurrentUser()
 * Obtiene el usuario actual basado en el token de autenticación
 * 
 * FLUJO:
 * 1. Extrae el token del header Authorization
 * 2. Busca en la tabla sessions con ese token
 * 3. Verifica que la sesión no haya expirado
 * 4. Verifica que el usuario esté activo
 * 5. Retorna los datos del usuario SIN la contraseña
 * 
 * RETORNA: array con datos del usuario, o null si:
 * - No hay token
 * - El token no existe en la BD
 * - La sesión ha expirado
 * - El usuario está inactivo
 */
function getCurrentUser() {
    $token = getBearerToken() ?: $_SESSION['session_token'] ?? null;
    if (!$token) {
        return null;
    }

    try {
        $db = getDB();
        $stmt = $db->prepare(
            "SELECT u.* FROM users u
             INNER JOIN sessions s ON u.id = s.user_id
             WHERE s.session_token = ?
               AND s.expires_at > NOW()
               AND u.active = 1"
        );
        $stmt->execute([$token]);
        $user = $stmt->fetch();

        if (!$user) {
            return null;
        }

        unset($user['password']);
        return $user;
    } catch (PDOException $e) {
        return null;
    }
}

/**
 * FUNCIÓN: requireAuth()
 * VALIDACIÓN OBLIGATORIA de autenticación
 * Termina la ejecución si el usuario no está autenticado
 * 
 * USO: Llamar al inicio de endpoints que requieren autenticación
 * 
 * COMPORTAMIENTO:
 * - Si hay usuario autenticado: retorna el objeto user
 * - Si NO hay usuario: envía respuesta JSON 401 y TERMINA ejecución
 * 
 * EJEMPLO:
 * function listTickets() {
 *   $user = requireAuth();  // Si falla, la función termina aquí
 *   // Aquí solo llegamos si $user es válido
 *   // ...resto de la lógica
 * }
 */
function requireAuth() {
    $user = getCurrentUser();
    if (!$user) {
        jsonResponse(['success' => false, 'error' => 'No autorizado'], 401);
    }
    return $user;
}

/**
 * FUNCIÓN: getTicketById()
 * Obtiene un ticket de la BD por su ID
 * 
 * PARÁMETROS:
 * - ticketId: string o int con el identificador del ticket
 * 
 * RETORNA: array con datos del ticket, o null si:
 * - El ID no existe
 * - Hay error de BD
 */
function getTicketById($ticketId) {
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM tickets WHERE id = ?");
        $stmt->execute([$ticketId]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        return null;
    }
}

/**
 * FUNCIÓN: userCanAccessTicket()
 * Valida si un usuario tiene permiso para acceder a un ticket
 * 
 * REGLAS DE ACCESO:
 * - USUARIOS (role=user): Solo ven sus propios tickets (created_by = user.id)
 * - AGENTES/ADMIN: Solo ven tickets asignados a ellos (assignee_id = user.id)
 * 
 * PARÁMETROS:
 * - user: array con datos del usuario autenticado
 * - ticket: array con datos del ticket
 * 
 * RETORNA: bool
 * - true: El usuario tiene acceso
 * - false: El usuario NO tiene acceso (rechazar petición con 403)
 * 
 * EJEMPLO:
 * $ticket = getTicketById('TK-001');
 * if (!userCanAccessTicket($user, $ticket)) {
 *   jsonResponse(['error' => 'Acceso denegado'], 403);
 * }
 */
function userCanAccessTicket(array $user, array $ticket) {
    if (!$ticket) {
        return false;
    }

    if (isset($user['role']) && $user['role'] === 'user') {
        return (int) $ticket['created_by'] === (int) $user['id'];
    }

    return (int) $ticket['assignee_id'] === (int) $user['id'];
}