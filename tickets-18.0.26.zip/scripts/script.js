/**
 * =============================================
 * Notification Manager - DECOMOBIL
 * Gestión centralizada de notificaciones
 * =============================================
 */

class NotificationManager {
  constructor() {
    this.API_BASE = '../xampp_project/api';
    this.lastCheckTime = Math.floor(Date.now() / 1000);
    this.isPolling = false;
    this.pollInterval = null;
  }

  /**
   * Inicializar: registrar Service Worker y solicitar permisos
   */
  async init() {
    console.log('[NotifManager] Inicializando...');
    
    // Registrar Service Worker
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/service-worker.js', {
          scope: '/'
        });
        console.log('[NotifManager] Service Worker registrado:', registration);
      } catch (error) {
        console.warn('[NotifManager] Error registrando Service Worker:', error);
      }
    }

    // Solicitar permiso para notificaciones
    if ('Notification' in window && Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      console.log('[NotifManager] Permiso de notificaciones:', permission);
    }

    // Escuchar mensajes del Service Worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', (event) => {
        console.log('[NotifManager] Mensaje desde SW:', event.data);
        if (event.data.type === 'NOTIFICATION_CLICKED') {
          this.handleNotificationClick(event.data);
        }
      });
    }

    // Iniciar polling de notificaciones
    this.startPolling();
  }

  /**
   * Iniciar polling en segundo plano
   */
  startPolling() {
    if (this.isPolling) return;
    this.isPolling = true;
    console.log('[NotifManager] Iniciando polling de notificaciones');
    
    // Polling cada 5 segundos
    this.pollInterval = setInterval(() => {
      this.checkNotifications();
    }, 5000);
    
    // Primer chequeo inmediato
    this.checkNotifications();
  }

  /**
   * Detener polling
   */
  stopPolling() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    this.isPolling = false;
    console.log('[NotifManager] Polling detenido');
  }

  /**
   * Chequear notificaciones usando API unificado
   */
  async checkNotifications() {
    const token = sessionStorage.getItem('auth_token');
    if (!token) return;

    try {
      const res = await fetch(`${this.API_BASE}/notifications.php?since=${this.lastCheckTime}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (!res.ok) return;

      const json = await res.json();
      if (!json.success) return;

      // Actualizar último tiempo de chequeo
      if (json.timestamp) {
        this.lastCheckTime = json.timestamp;
      }

      // Procesar noticias
      if (Array.isArray(json.news)) {
        json.news.forEach(n => {
          this.showNotification(n.title || 'Nueva noticia', {
            body: n.description || '',
            icon: '/rc/decomobil_logo.ico',
            tag: `news-${n.id}`,
            data: {
              type: 'news',
              newsId: n.id,
              newsTitle: n.title
            }
          });
        });
      }

      // Procesar actividad de chat
      if (Array.isArray(json.activity)) {
        const currentUser = JSON.parse(sessionStorage.getItem('user_session') || '{}');
        json.activity.forEach(a => {
          if (a.user_name !== currentUser.name && a.message) {
            this.showNotification(`💬 ${a.user_name}`, {
              body: a.message.substring(0, 100),
              icon: '/rc/decomobil_logo.ico',
              tag: `chat-${a.ticket_id}`,
              data: {
                type: 'chat',
                ticketId: a.ticket_id,
                ticketTitle: `Ticket ${a.ticket_id}`
              }
            });
          }
        });
      }
    } catch (error) {
      console.error('[NotifManager] Error chequeando notificaciones:', error);
    }
  }

  /**
   * Mostrar notificación
   */
  showNotification(title, options = {}) {
    // Usar Notification API directamente
    if ('Notification' in window && Notification.permission === 'granted') {
      // Mostrar siempre, sin importar si la ventana está visible
      try {
        new Notification(title, {
          icon: '/rc/decomobil_logo.ico',
          badge: '/rc/decomobil_logo.ico',
          requireInteraction: false,
          ...options
        });
      } catch (e) {
        console.error('[NotifManager] Error mostrando notificación:', e);
      }
    }
  }

  /**
   * Manejar clicks en notificaciones
   */
  handleNotificationClick(data) {
    console.log('[NotifManager] Notificación clickeada:', data);
    
    if (data.ticketId) {
      // Enviar a pestaña específica o abrir
      if (window.location.href.includes('home.php') || window.location.href.includes('admin.php')) {
        // Si estamos en home/admin, abrir el ticket
        if (typeof TicketChat !== 'undefined' && TicketChat.open) {
          TicketChat.open(data.ticketId, data.ticketTitle);
        }
      } else {
        window.location.href = '/src/home.php';
      }
    } else if (data.newsId) {
      // Mostrar panel de noticias
      if (window.location.href.includes('home.php')) {
        const panel = document.getElementById('newsPanel');
        if (panel) {
          panel.classList.add('open');
        }
      } else {
        window.location.href = '/src/home.php';
      }
    }
  }
}

// Inicializar cuando el DOM esté listo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.notificationManager = new NotificationManager();
    window.notificationManager.init();
  });
} else {
  window.notificationManager = new NotificationManager();
  window.notificationManager.init();
}
/**
 * =============================================
 * Notification Manager - DECOMOBIL
 * Gestión centralizada de notificaciones
 * =============================================
 */

class NotificationManager {
  constructor() {
    this.API_BASE = '../xampp_project/api';
    this.lastCheckTime = Math.floor(Date.now() / 1000);
    this.isPolling = false;
    this.pollInterval = null;
  }

  /**
   * Inicializar: registrar Service Worker y solicitar permisos
   */
  async init() {
    console.log('[NotifManager] Inicializando...');
    
    // Registrar Service Worker
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/service-worker.js', {
          scope: '/'
        });
        console.log('[NotifManager] Service Worker registrado:', registration);
      } catch (error) {
        console.warn('[NotifManager] Error registrando Service Worker:', error);
      }
    }

    // Solicitar permiso para notificaciones
    if ('Notification' in window && Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      console.log('[NotifManager] Permiso de notificaciones:', permission);
    }

    // Escuchar mensajes del Service Worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', (event) => {
        console.log('[NotifManager] Mensaje desde SW:', event.data);
        if (event.data.type === 'NOTIFICATION_CLICKED') {
          this.handleNotificationClick(event.data);
        }
      });
    }

    // Iniciar polling de notificaciones
    this.startPolling();
  }

  /**
   * Iniciar polling en segundo plano
   */
  startPolling() {
    if (this.isPolling) return;
    this.isPolling = true;
    console.log('[NotifManager] Iniciando polling de notificaciones');
    
    // Polling cada 5 segundos
    this.pollInterval = setInterval(() => {
      this.checkNotifications();
    }, 5000);
    
    // Primer chequeo inmediato
    this.checkNotifications();
  }

  /**
   * Detener polling
   */
  stopPolling() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    this.isPolling = false;
    console.log('[NotifManager] Polling detenido');
  }

  /**
   * Chequear notificaciones usando API unificado
   */
  async checkNotifications() {
    const token = sessionStorage.getItem('auth_token');
    if (!token) return;

    try {
      const res = await fetch(`${this.API_BASE}/notifications.php?since=${this.lastCheckTime}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (!res.ok) return;

      const json = await res.json();
      if (!json.success) return;

      // Actualizar último tiempo de chequeo
      if (json.timestamp) {
        this.lastCheckTime = json.timestamp;
      }

      // Procesar noticias
      if (Array.isArray(json.news)) {
        json.news.forEach(n => {
          this.showNotification(n.title || 'Nueva noticia', {
            body: n.description || '',
            icon: '/rc/decomobil_logo.ico',
            tag: `news-${n.id}`,
            data: {
              type: 'news',
              newsId: n.id,
              newsTitle: n.title
            }
          });
        });
      }

      // Procesar actividad de chat
      if (Array.isArray(json.activity)) {
        const currentUser = JSON.parse(sessionStorage.getItem('user_session') || '{}');
        json.activity.forEach(a => {
          if (a.user_name !== currentUser.name && a.message) {
            this.showNotification(`💬 ${a.user_name}`, {
              body: a.message.substring(0, 100),
              icon: '/rc/decomobil_logo.ico',
              tag: `chat-${a.ticket_id}`,
              data: {
                type: 'chat',
                ticketId: a.ticket_id,
                ticketTitle: `Ticket ${a.ticket_id}`
              }
            });
          }
        });
      }
    } catch (error) {
      console.error('[NotifManager] Error chequeando notificaciones:', error);
    }
  }

  /**
   * Mostrar notificación
   */
  showNotification(title, options = {}) {
    // Usar Notification API directamente
    if ('Notification' in window && Notification.permission === 'granted') {
      // Mostrar siempre, sin importar si la ventana está visible
      try {
        new Notification(title, {
          icon: '/rc/decomobil_logo.ico',
          badge: '/rc/decomobil_logo.ico',
          requireInteraction: false,
          ...options
        });
      } catch (e) {
        console.error('[NotifManager] Error mostrando notificación:', e);
      }
    }
  }

  /**
   * Manejar clicks en notificaciones
   */
  handleNotificationClick(data) {
    console.log('[NotifManager] Notificación clickeada:', data);
    
    if (data.ticketId) {
      // Enviar a pestaña específica o abrir
      if (window.location.href.includes('home.php') || window.location.href.includes('admin.php')) {
        // Si estamos en home/admin, abrir el ticket
        if (typeof TicketChat !== 'undefined' && TicketChat.open) {
          TicketChat.open(data.ticketId, data.ticketTitle);
        }
      } else {
        window.location.href = '/src/home.php';
      }
    } else if (data.newsId) {
      // Mostrar panel de noticias
      if (window.location.href.includes('home.php')) {
        const panel = document.getElementById('newsPanel');
        if (panel) {
          panel.classList.add('open');
        }
      } else {
        window.location.href = '/src/home.php';
      }
    }
  }
}

// Inicializar cuando el DOM esté listo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.notificationManager = new NotificationManager();
    window.notificationManager.init();
  });
} else {
  window.notificationManager = new NotificationManager();
  window.notificationManager.init();
}
/**
 * =============================================
 * Service Worker - DECOMOBIL
 * Notificaciones push en segundo plano
 * =============================================
 */

const CACHE_NAME = 'decomobil-v1';

// Instalación del Service Worker
self.addEventListener('install', (event) => {
  console.log('[SW] Installing...');
  self.skipWaiting();
});

// Activación del Service Worker
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating...');
  event.waitUntil(self.clients.claim());
});

// Manejo de notificaciones push
self.addEventListener('push', (event) => {
  console.log('[SW] Push notification received:', event);
  
  if (event.data) {
    try {
      const data = event.data.json();
      
      const options = {
        body: data.body || 'Nueva notificación',
        icon: '/rc/decomobil_logo.ico',
        badge: '/rc/decomobil_logo.ico',
        tag: data.tag || 'notification',
        requireInteraction: false,
        data: data.data || {}
      };
      
      event.waitUntil(
        self.registration.showNotification(data.title || 'DECOMOBIL', options)
      );
    } catch (e) {
      console.error('[SW] Error parsing push:', e);
        event.waitUntil(
        self.registration.showNotification('DECOMOBIL', {
          body: event.data.text(),
          icon: '/rc/decomobil_logo.ico'
        })
      );
    }
  }
});

// Manejo de clicks en notificaciones
self.addEventListener('notificationclick', (event) => {
  console.log('[SW] Notification clicked:', event);
  event.notification.close();
  
  const data = event.notification.data || {};
  const clientData = {
    type: 'NOTIFICATION_CLICKED',
    ticketId: data.ticketId,
    newsId: data.newsId,
    timestamp: Date.now()
  };
  
  event.waitUntil(
    self.clients.matchAll({ type: 'window' }).then((clients) => {
      // Si existe una ventana abierta, enviar mensaje
      for (let i = 0; i < clients.length; i++) {
        if (clients[i].url.includes('home.php') || clients[i].url.includes('admin.php')) {
          return clients[i].postMessage(clientData);
        }
      }
      // Si no hay ventana, abrir una
      if (self.clients.openWindow) {
        return self.clients.openWindow('/src/home.php');
      }
    })
  );
});

// Escuchar mensajes desde el cliente
self.addEventListener('message', (event) => {
  console.log('[SW] Message received:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
