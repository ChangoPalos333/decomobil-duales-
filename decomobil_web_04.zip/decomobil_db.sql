-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-04-2026 a las 03:40:35
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `decomobil_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sessions`
--

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `session_token`, `expires_at`, `created_at`) VALUES
(1, 5, '441665d7bce2010f8222ec8a2b4aa8182a40ebf42b211fd68e450c459ddc0292', '2026-04-16 18:23:09', '2026-04-15 16:23:09'),
(2, 1, '15ccc4805672a63eca1122dfe4b73a0dd8d74b320ebda3887318e508c84cb7f6', '2026-04-16 18:24:31', '2026-04-15 16:24:31'),
(3, 3, 'e5f3402af7c261cd1f468f26f824cf2196f43531af1fafb06171a7ccb4ce87a2', '2026-04-16 18:53:29', '2026-04-15 16:53:29'),
(4, 3, 'd78e0d716ad5d45982ed687d6835a235f281b40881762f8530d53a0501c1312d', '2026-04-16 18:58:46', '2026-04-15 16:58:46'),
(5, 5, '58d7d9593dd167e479968cd7a3ed240cb83bc3c14bbe135c17048ffd58eaa583', '2026-04-16 20:13:29', '2026-04-15 18:13:29'),
(6, 3, 'aa16dddf1146f24706c5f78d3e8be8b512ff516026cb77b57e1ac124ff4bf9e3', '2026-04-16 20:16:24', '2026-04-15 18:16:24'),
(7, 5, '7f96ec6bbfedae49d85f6de9f5c764d92f65e0eacd9bdfbace814a4cd4742ddd', '2026-04-16 20:17:18', '2026-04-15 18:17:18'),
(8, 2, '1a3e51fc3ac6de561eecbeb9d2d7ee19463f9db509437706cadf093e80b55ead', '2026-04-16 20:18:40', '2026-04-15 18:18:40'),
(9, 3, 'd70928f6e6082f97f4f1798517321e883d628a7f3b17e92b2e19573922452986', '2026-04-16 20:31:36', '2026-04-15 18:31:36'),
(10, 4, '0b237ee30fd247f5a03e98f864bc84d9cf686c045692e65702cc723aac35d2d8', '2026-04-16 20:54:00', '2026-04-15 18:54:00'),
(11, 6, 'ef2fbf96862e15e1b16ff0a15ad9b33ba905fec7013c6e5393d123088ada4e7b', '2026-04-16 21:03:20', '2026-04-15 19:03:20'),
(12, 6, 'b8010ff03862672ff9277e701d789564e1ce9d9b6223b835d2c1e46753ac1cad', '2026-04-16 22:02:59', '2026-04-15 20:02:59'),
(13, 6, '9d551f590cdde1765971cab1fb04ee497c56d8c67d88ad326dc891fc3cb168cd', '2026-04-16 23:00:31', '2026-04-15 21:00:31'),
(14, 5, '6d8368100405d362ea7c2a1effb9f27bc44aa5bef866cf6bc27d6aedd6645051', '2026-04-16 23:19:15', '2026-04-15 21:19:15'),
(15, 6, '194fad6a1af6a8a30b1372ae3988fea364e23a2734b006940f430ea08ecccf6d', '2026-04-16 23:20:05', '2026-04-15 21:20:05'),
(16, 5, 'ee8439eb92910743ec4114271eaefdd77f3529df46cf944e5f0823013c264c99', '2026-04-16 23:20:24', '2026-04-15 21:20:24'),
(17, 6, '51ed071ac30fc51fe45f67a151eee56e08304ca5c571cfffea2a03c10c53afb1', '2026-04-16 23:20:56', '2026-04-15 21:20:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tickets`
--

CREATE TABLE `tickets` (
  `id` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `priority` enum('Critica','Alta','Media','Baja') DEFAULT 'Media',
  `status` enum('Abierto','En Progreso','En Revision','Pendiente','Resuelto') DEFAULT 'Abierto',
  `category` varchar(50) DEFAULT 'TI',
  `dept` varchar(50) DEFAULT NULL,
  `assignee_id` int(11) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `due_date` date DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tickets`
--

INSERT INTO `tickets` (`id`, `title`, `description`, `priority`, `status`, `category`, `dept`, `assignee_id`, `created_by`, `due_date`, `resolved_at`, `created_at`, `updated_at`) VALUES
('TK-001', 'Falla en conexion VPN del area de ventas', 'Los usuarios del area de ventas no pueden conectarse a la VPN corporativa desde las 8am. Afecta a 7 personas.', 'Critica', 'Resuelto', 'TI', 'Ventas', 2, 5, '2026-04-17', '2026-04-15 12:38:47', '2026-04-14 18:40:32', '2026-04-15 18:38:47'),
('TK-002', 'Solicitud de equipo: monitor adicional para diseno', 'El area de diseno necesita un monitor adicional para mejorar la productividad.', 'Media', 'Abierto', 'TI', 'Produccion', NULL, 4, '2026-04-21', NULL, '2026-04-14 18:40:32', '2026-04-14 18:40:32'),
('TK-003', 'Actualizacion de permisos en sistema ERP', 'Se requiere actualizar permisos del modulo de compras para usuario promovido.', 'Alta', 'En Revision', 'TI', 'Administracion', 3, 1, '2026-04-15', NULL, '2026-04-14 18:40:32', '2026-04-14 18:40:32'),
('TK-004', 'Error en nomina - calculo de horas extra', 'Error en calculo de horas extra para turno nocturno. Afecta a 12 colaboradores.', 'Alta', 'Resuelto', 'CONT', 'Finanzas', 2, 4, '2026-04-15', '2026-04-15 12:36:44', '2026-04-14 18:40:32', '2026-04-15 18:36:44'),
('TK-005', 'Solicitud capacitacion: Excel avanzado', 'Equipo de logistica solicita capacitacion de Excel avanzado para 8 personas.', 'Baja', 'En Progreso', 'TI', 'Logistica', NULL, 5, '2026-04-28', NULL, '2026-04-14 18:40:32', '2026-04-15 21:21:34'),
('TK-006', 'Falla impresora piso 3', 'Impresora HP del piso 3 no responde. Necesita revision urgente.', 'Media', 'Resuelto', 'TI', 'Administracion', 3, 1, '2026-04-14', NULL, '2026-04-14 18:40:32', '2026-04-14 18:40:32'),
('TK-007', 'Se robaron un marcador en el area de fucking calidad pixe', 'Ya no hay marcadores y se robaron otro no mms cfffffff', 'Critica', 'Resuelto', 'TI', 'Administracion', 3, 3, NULL, '2026-04-15 12:16:49', '2026-04-15 17:11:35', '2026-04-15 18:16:49'),
('TK-008', 'Hola pibes como estaaaan', 'Iijijijijiji', 'Critica', 'Resuelto', 'TI', 'Administracion', 2, 2, NULL, '2026-04-15 12:33:46', '2026-04-15 17:21:36', '2026-04-15 18:33:46'),
('TK-009', 'Edwin huele a qlo', 'Y no tiene prepucio jaaaa que pendejo quien no tiene prepucio en pleno 2026????? pinche joto ajskdas', 'Baja', 'Resuelto', 'TI', 'RRHH', 4, 2, NULL, '2026-04-15 12:33:38', '2026-04-15 18:33:00', '2026-04-15 18:33:38'),
('TK-010', 'chachacha', 'chachacha', 'Alta', 'En Progreso', 'TI', 'Administracion', 2, 2, NULL, NULL, '2026-04-15 18:48:13', '2026-04-15 18:48:40'),
('TK-011', 'No funciona el creador de tickets', 'Sigue sin funcionar pije', 'Alta', 'Abierto', 'TI', 'Ventas', 6, 6, NULL, NULL, '2026-04-15 20:54:15', '2026-04-15 20:54:15'),
('TK-012', 'Ya jala pijes aweboooo', 'Ya funciona tu chingadera cffffff', 'Baja', 'Abierto', 'TI', 'RRHH', 6, 6, '2026-04-22', NULL, '2026-04-15 20:58:39', '2026-04-15 20:58:39'),
('TK-013', 'Ya funciona la creacion de tickets', 'Ya jala ya jalaaa', 'Alta', 'Abierto', 'TI', 'Finanzas', NULL, 6, '2026-04-22', NULL, '2026-04-15 21:04:23', '2026-04-15 21:04:23'),
('TK-014', 'Se robaron la lapicera favorita de Sergio', 'sjkjslkjdlkajsd', 'Media', 'En Progreso', 'TI', 'Administración', NULL, 6, '2026-04-22', '2026-04-15 15:12:04', '2026-04-15 21:11:04', '2026-04-15 21:12:11'),
('TK-015', 'Ya funcaaa', 'ja la ja la jala estamadre', 'Baja', 'Abierto', 'RRHH', 'Producción', 2, 6, '2026-04-22', NULL, '2026-04-15 21:23:51', '2026-04-15 21:23:51'),
('TK-016', 'Se necesitan estanterias en el area de calidad', 'Se solicita la instalcion de estanterias en el area de calidad para el almacenamiento temporal de escombros de ovalines y de mas', 'Media', 'Abierto', 'TI', 'Administración', 6, 6, '2026-04-22', NULL, '2026-04-15 21:37:14', '2026-04-15 21:37:14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ticket_activity`
--

CREATE TABLE `ticket_activity` (
  `id` int(11) NOT NULL,
  `ticket_id` varchar(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `activity_type` enum('create','comment','status','assign','resolve') DEFAULT 'comment',
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ticket_activity`
--

INSERT INTO `ticket_activity` (`id`, `ticket_id`, `user_name`, `activity_type`, `message`, `created_at`) VALUES
(1, 'TK-001', 'Sistema', 'create', 'Ticket creado', '2026-04-14 18:40:32'),
(2, 'TK-001', 'Ana Garcia', 'comment', 'Revisando configuracion de VPN', '2026-04-14 18:40:32'),
(3, 'TK-002', 'Sistema', 'create', 'Ticket creado', '2026-04-14 18:40:32'),
(4, 'TK-003', 'Sistema', 'create', 'Ticket creado', '2026-04-14 18:40:32'),
(5, 'TK-003', 'Carlos Lopez', 'comment', 'Revisando con admin del ERP.', '2026-04-14 18:40:32'),
(6, 'TK-004', 'Sistema', 'create', 'Ticket creado', '2026-04-14 18:40:32'),
(7, 'TK-005', 'Sistema', 'create', 'Ticket creado', '2026-04-14 18:40:32'),
(8, 'TK-006', 'Sistema', 'create', 'Ticket creado', '2026-04-14 18:40:32'),
(9, 'TK-006', 'Carlos Lopez', 'resolve', 'Problema resuelto - se reemplazo toner', '2026-04-14 18:40:32'),
(10, 'TK-007', 'Sistema', 'assign', 'Asignado a Carlos Lopez', '2026-04-15 18:16:45'),
(11, 'TK-007', 'Sistema', 'status', 'Estado cambiado a Resuelto', '2026-04-15 18:16:49'),
(12, 'TK-009', 'Sistema', 'status', 'Estado cambiado a Resuelto', '2026-04-15 18:33:38'),
(13, 'TK-008', 'Sistema', 'status', 'Estado cambiado a Resuelto', '2026-04-15 18:33:46'),
(14, 'TK-004', 'Sistema', 'status', 'Estado cambiado a Resuelto', '2026-04-15 18:36:44'),
(15, 'TK-001', 'Sistema', 'status', 'Estado cambiado a Resuelto', '2026-04-15 18:38:47'),
(16, 'TK-010', 'Sistema', 'status', 'Estado cambiado a En Progreso', '2026-04-15 18:48:40'),
(17, 'TK-011', 'Sistema', 'create', 'Ticket creado', '2026-04-15 20:54:15'),
(18, 'TK-012', 'Sistema', 'create', 'Ticket creado', '2026-04-15 20:58:39'),
(19, 'TK-013', 'Sistema', 'create', 'Ticket creado', '2026-04-15 21:04:23'),
(20, 'TK-014', 'Sistema', 'create', 'Ticket creado', '2026-04-15 21:11:04'),
(21, 'TK-014', 'Sistema', 'status', 'Estado cambiado a En Progreso', '2026-04-15 21:12:01'),
(22, 'TK-014', 'Sistema', 'status', 'Estado cambiado a Resuelto', '2026-04-15 21:12:04'),
(23, 'TK-014', 'Sistema', 'status', 'Estado cambiado a En Progreso', '2026-04-15 21:12:11'),
(24, 'TK-013', 'Pedro Ruiz', 'comment', 'hola pibes', '2026-04-15 21:20:39'),
(25, 'TK-005', 'Sistema', 'status', 'Estado cambiado a En Progreso', '2026-04-15 21:21:34'),
(26, 'TK-015', 'Sistema', 'create', 'Ticket creado', '2026-04-15 21:23:51'),
(27, 'TK-016', 'Sistema', 'create', 'Ticket creado', '2026-04-15 21:37:14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','agent','user') DEFAULT 'user',
  `dept` varchar(50) DEFAULT NULL,
  `avatar` varchar(20) DEFAULT '#0F52BA',
  `active` tinyint(1) DEFAULT 1,
  `created_at` date DEFAULT curdate(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `dept`, `avatar`, `active`, `created_at`, `updated_at`) VALUES
(1, 'Administrador General', 'admin@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Direccion', '#0F52BA', 1, '2025-01-01', '2026-04-14 18:40:31'),
(2, 'Ana Garcia', 'ana@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'agent', 'TI', '#15803D', 1, '2025-01-15', '2026-04-14 18:40:31'),
(3, 'Carlos Lopez', 'carlos@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'agent', 'TI', '#B45309', 1, '2025-01-15', '2026-04-14 18:40:31'),
(4, 'Maria Torres', 'maria@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user', 'Contabilidad', '#6D28D9', 1, '2025-02-01', '2026-04-14 18:40:31'),
(5, 'Pedro Ruiz', 'pedro@empresa.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user', 'Ventas', '#D93025', 1, '2025-02-10', '2026-04-14 18:40:31'),
(6, 'Carlos Acosta', 'carlosA@empresa.com', '$2y$10$ygCE..O51VtHIOE5s7.zuOWccovTrP0v7u82iGOTA2quQBjJ1ljD6', 'admin', 'Direccion', '#0DD100', 1, '2026-04-15', '2026-04-15 19:02:53');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `session_token` (`session_token`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tickets_status` (`status`),
  ADD KEY `idx_tickets_priority` (`priority`),
  ADD KEY `idx_tickets_assignee` (`assignee_id`),
  ADD KEY `idx_tickets_created_by` (`created_by`);

--
-- Indices de la tabla `ticket_activity`
--
ALTER TABLE `ticket_activity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_activity_ticket` (`ticket_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `ticket_activity`
--
ALTER TABLE `ticket_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`assignee_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `ticket_activity`
--
ALTER TABLE `ticket_activity`
  ADD CONSTRAINT `ticket_activity_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
