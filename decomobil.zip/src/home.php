<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Inicio — Decomobil</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
/* Login is fixed overlay, no flash prevention needed */
/* ═══════════════════ TOKENS ═══════════════════ */
:root {
  --ink:#0E1117; --ink2:#374151; --ink3:#6B7280; --ink4:#9CA3AF;
  --bg:#F7F8FA; --bg2:#EDEEF1;
  --surface:#FFFFFF; --surface2:#F9FAFB;
  --border:#E5E7EB; --border2:#D1D5DB;
  --primary:#0F52BA; --primary-dark:#0A3D8F; --primary-light:#EBF0FB;
  --red:#C0392B; --red-light:#FEF2F2;
  --amber:#B45309; --amber-light:#FFFBEB;
  --green:#15803D; --green-light:#F0FDF4;
  --violet:#6D28D9; --violet-light:#F5F3FF;
  --teal:#0D9488;
  --display:'Arial'; --body:'Arial'; --mono:'Arial';
  --radius:10px; --radius-sm:6px; --radius-lg:16px;
  --shadow-sm:0 1px 4px rgba(0,0,0,.08); --shadow:0 4px 16px rgba(0,0,0,.10); --shadow-lg:0 20px 48px rgba(0,0,0,.15);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--body);background:var(--bg);color:var(--ink);-webkit-font-smoothing:antialiased;min-height:100vh}
a{color:inherit;text-decoration:none}
button{font-family:var(--body);cursor:pointer;border:none;background:none}
input,select,textarea{font-family:var(--body)}
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px}

/* ═══ NAVBAR ═══ */
#mainNav{position:fixed;top:0;left:0;right:0;height:60px;background:#0E1117;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;padding:0 24px;z-index:1000;gap:0}
.nav-brand{display:flex;align-items:center;gap:10px;color:#fff;flex-shrink:0;text-decoration:none}
.nav-logo{width:32px;height:32px;background:var(--primary);border-radius:8px;display:grid;place-items:center;font-family:var(--display);font-size:13px;font-weight:800;color:#fff}
.nav-name{font-family:var(--display);font-size:18px;font-weight:700;color:#fff;letter-spacing:-.3px}
.nav-sep{width:1px;height:22px;background:rgba(255,255,255,.1);margin:0 18px}
#navLinks{display:flex;align-items:center;gap:2px;flex:1}
.nav-link{display:flex;align-items:center;gap:6px;padding:6px 12px;border-radius:7px;font-size:13px;font-weight:500;color:rgba(255,255,255,.55);cursor:pointer;transition:all .15s;white-space:nowrap;border:1px solid transparent}
.nav-link:hover{color:#fff;background:rgba(255,255,255,.07)}
.nav-link.active{color:#fff;background:rgba(255,255,255,.10);border-color:rgba(255,255,255,.12);font-weight:600}
#navRight{display:flex;align-items:center;gap:8px;margin-left:auto}
.nav-user{display:flex;align-items:center;gap:8px;padding:4px 12px 4px 4px;border-radius:20px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);cursor:pointer}
.nav-user:hover{background:rgba(255,255,255,.12)}
.nav-avatar{width:28px;height:28px;border-radius:50%;display:grid;place-items:center;font-size:10px;font-weight:700;color:#fff}
.nav-uname{font-size:12.5px;font-weight:500;color:rgba(255,255,255,.8)}
.nav-btn{height:32px;padding:0 14px;border-radius:7px;font-size:12.5px;font-weight:600;display:inline-flex;align-items:center;gap:6px;cursor:pointer;transition:all .15s}
.nb-primary{background:var(--primary);color:#fff}
.nb-primary:hover{background:var(--primary-dark)}
.nb-ghost{border:1px solid rgba(255,255,255,.2);color:rgba(255,255,255,.65)}
.nb-ghost:hover{background:rgba(255,255,255,.08);color:#fff}

/* ═══ PAGE ═══ */
.page{padding-top:60px;min-height:100vh;display:flex;flex-direction:column}
.section{display:none;flex:1;flex-direction:column}
.section.active{display:flex}

/* ═══ BUTTONS ═══ */
.btn{display:inline-flex;align-items:center;gap:7px;height:36px;padding:0 18px;border-radius:var(--radius-sm);font-size:13.5px;font-weight:600;cursor:pointer;transition:all .15s;border:1.5px solid transparent;white-space:nowrap;font-family:var(--body)}
.btn-sm{height:30px;padding:0 12px;font-size:12px}
.btn-lg{height:44px;padding:0 28px;font-size:14px;border-radius:8px}
.btn-primary{background:var(--primary);color:#fff;border-color:var(--primary)}
.btn-primary:hover{background:var(--primary-dark)}
.btn-ghost{border-color:var(--border2);color:var(--ink2);background:var(--surface)}
.btn-ghost:hover{background:var(--bg)}
.btn-danger{background:var(--red);color:#fff}
.btn-danger:hover{background:#a93226}
.btn-success{background:var(--green);color:#fff}

/* ═══ FIELDS ═══ */
.fg{display:flex;flex-direction:column;gap:5px}
.fl{font-size:12px;font-weight:600;color:var(--ink2)}
.fl .r{color:var(--red)}
.fi,.fs,.ft{width:100%;border:1.5px solid var(--border);border-radius:var(--radius-sm);padding:8px 11px;font-size:13.5px;color:var(--ink);background:var(--surface);outline:none;transition:border-color .15s,box-shadow .15s;font-family:var(--body)}
.fi:focus,.fs:focus,.ft:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(15,82,186,.12)}
.ft{resize:vertical;min-height:80px;line-height:1.5}
.fe{font-size:11.5px;color:var(--red);display:none}
.fe.show{display:block}
.fg2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.fg3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}

/* ═══ BADGES ═══ */
.badge{display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:5px;font-size:11.5px;font-weight:600;white-space:nowrap}
.bd{width:5px;height:5px;border-radius:50%;flex-shrink:0}
.b-open{background:var(--primary-light);color:var(--primary)}
.b-progress{background:var(--amber-light);color:var(--amber)}
.b-review{background:var(--violet-light);color:var(--violet)}
.b-pending{background:var(--bg2);color:var(--ink3);border:1px solid var(--border)}
.b-resolved{background:var(--green-light);color:var(--green)}
.b-red{background:var(--red-light);color:var(--red)}
.b-critical{background:rgba(248,113,113,.14);color:var(--red);border:1px solid rgba(248,113,113,.3)}
.b-high{background:rgba(248,113,113,.08);color:var(--red);border:1px solid rgba(248,113,113,.18)}
.b-medium{background:rgba(251,191,36,.12);color:var(--amber);border:1px solid rgba(251,191,36,.2)}
.b-low{background:rgba(34,197,94,.12);color:var(--green);border:1px solid rgba(34,197,94,.2)}

/* ═══ CARDS ═══ */
.card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px}
.ct{font-family:var(--display);font-size:15px;font-weight:700;color:var(--ink);margin-bottom:14px}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:16px 18px;display:flex;flex-direction:column;gap:6px;position:relative;overflow:hidden;transition:box-shadow .2s,transform .15s}
.stat-card:hover{box-shadow:var(--shadow);transform:translateY(-1px)}
.stat-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px}
.sc-blue::before{background:var(--primary)} .sc-red::before{background:var(--red)}
.sc-amber::before{background:var(--amber)} .sc-green::before{background:var(--green)}
.sc-violet::before{background:var(--violet)}
.sc-violet::before{background:var(--violet)}
.sv{font-family:var(--display);font-size:30px;font-weight:800;color:var(--ink);line-height:1;letter-spacing:-1px}
.sl{font-size:12px;color:var(--ink3);font-weight:500}
.ss{font-size:11px;color:var(--ink4)}

/* ═══ MODAL ═══ */
.overlay{position:fixed;inset:0;background:rgba(14,17,23,.55);backdrop-filter:blur(3px);z-index:2000;display:none;align-items:center;justify-content:center;padding:20px}
.overlay.open{display:flex;animation:fade-in .2s ease}
@keyframes fade-in{from{opacity:0}to{opacity:1}}
.modal{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);width:100%;max-width:560px;max-height:calc(100vh - 40px);display:flex;flex-direction:column;overflow:hidden;animation:modal-in .25s cubic-bezier(.34,1.4,.64,1)}
.modal-wide{max-width:680px}
@keyframes modal-in{from{opacity:0;transform:scale(.94) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}
.mh{padding:18px 20px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.mt{font-family:var(--display);font-size:15px;font-weight:700;color:var(--ink)}
.mc{width:28px;height:28px;border-radius:6px;display:grid;place-items:center;color:var(--ink3);cursor:pointer;transition:all .12s}
.mc:hover{background:var(--bg)}
.mb{padding:20px;overflow-y:auto;display:flex;flex-direction:column;gap:14px;flex:1}
.mf{padding:14px 20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px;background:var(--surface2);flex-shrink:0}

/* ═══ TOAST ═══ */
#toastContainer{position:fixed;bottom:20px;right:20px;display:flex;flex-direction:column-reverse;gap:8px;z-index:9999;pointer-events:none}
.toast{display:flex;align-items:center;gap:10px;padding:11px 16px;border-radius:var(--radius-sm);font-size:13.5px;font-weight:500;color:#fff;box-shadow:var(--shadow);min-width:240px;max-width:340px;animation:toast-in .3s cubic-bezier(.34,1.4,.64,1);pointer-events:auto;background:var(--ink)}
.toast.success{background:#166534} .toast.error{background:#991b1b} .toast.warning{background:#92400e}
@keyframes toast-in{from{opacity:0;transform:translateX(20px) scale(.95)}to{opacity:1;transform:translateX(0) scale(1)}}

/* ═══ TABLE ═══ */
.dt{width:100%;border-collapse:collapse}
.dt th{padding:10px 14px;text-align:left;font-size:10.5px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--ink3);background:var(--surface2);border-bottom:1px solid var(--border);white-space:nowrap}
.dt td{padding:11px 14px;font-size:13px;color:var(--ink2);border-bottom:1px solid var(--border);vertical-align:middle}
.dt tr:last-child td{border-bottom:none}
.dt tr:hover td{background:var(--surface2)}
.dt tr{transition:background .1s}

/* ═══ SIDE PANEL ═══ */
#detailPanel{position:fixed;top:60px;right:0;bottom:0;width:460px;background:var(--surface);border-left:1px solid var(--border);box-shadow:-8px 0 32px rgba(0,0,0,.08);z-index:900;display:none;flex-direction:column;overflow:hidden}
#detailPanel.open{display:flex;animation:panel-in .22s ease}
@keyframes panel-in{from{transform:translateX(20px);opacity:0}to{transform:translateX(0);opacity:1}}

/* ═══ AVATAR ═══ */
.avatar{border-radius:50%;display:grid;place-items:center;font-weight:700;color:#fff;flex-shrink:0}

/* ═══ LOGIN ═══ */
/* ══ LOGIN SCREEN (fullscreen fixed, hides app) ══ */
#section-login{position:fixed;inset:0;z-index:9999;background:#0E1117;display:none;grid-template-columns:1fr 1fr}
#section-login.active{display:grid}
.ll{background:linear-gradient(160deg,#0E1117 0%,#0c2d6b 55%,#0F52BA 100%);display:flex;flex-direction:column;justify-content:space-between;padding:48px;position:relative;overflow:hidden}
.ll::before{content:'';position:absolute;width:500px;height:500px;border-radius:50%;background:radial-gradient(circle,rgba(15,82,186,.35) 0%,transparent 70%);top:-100px;right:-100px;pointer-events:none}
.ll::after{content:'';position:absolute;width:300px;height:300px;border-radius:50%;background:radial-gradient(circle,rgba(15,82,186,.2) 0%,transparent 70%);bottom:-60px;left:60px;pointer-events:none}
.lgrid{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.03) 1px,transparent 1px);background-size:40px 40px;pointer-events:none}
.lr{background:#fff;display:flex;align-items:center;justify-content:center;padding:48px 40px}
.lbox{width:100%;max-width:380px;animation:lappear .5s cubic-bezier(.34,1.2,.64,1) both}
@keyframes lappear{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
.di{display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:#fff;border:1.5px solid var(--border);border-radius:7px;cursor:pointer;transition:border-color .15s,box-shadow .12s;margin-bottom:6px}
.di:last-child{margin-bottom:0}
.di:hover{border-color:var(--primary);box-shadow:0 0 0 3px rgba(15,82,186,.08)}
.lbtn{width:100%;height:46px;background:var(--primary);color:#fff;border:none;border-radius:8px;font-family:var(--display);font-size:15px;font-weight:700;cursor:pointer;transition:all .15s;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 4px 16px rgba(15,82,186,.3);margin-bottom:24px}
.lbtn:hover{background:var(--primary-dark);box-shadow:0 6px 20px rgba(15,82,186,.4)}
.lbtn:active{transform:scale(.98)}
#loginError{display:none;background:var(--red-light);color:var(--red);font-size:13px;padding:10px 14px;border-radius:7px;border-left:3px solid var(--red);margin-bottom:16px;font-weight:500}
#loginError.vis{display:block;animation:lshake .3s ease}
@keyframes lshake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
@media(max-width:768px){#section-login{grid-template-columns:1fr}.ll{display:none}}

/* ═══ COMPANY PAGE ═══ */
.company-hero{background:linear-gradient(135deg,#0E1117,#0F52BA);padding:56px 48px;color:#fff;position:relative;overflow:hidden}
.company-hero::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at 70% 50%,rgba(255,255,255,.06),transparent 60%)}
.pillar-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;padding:32px 48px}
.pillar-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;transition:box-shadow .2s,transform .15s}
.pillar-card:hover{box-shadow:var(--shadow);transform:translateY(-2px)}

/* ═══ ORG CHART ═══ */
.org-section{padding:32px 48px}
.org-tree{display:flex;flex-direction:column;align-items:center;gap:0;padding:24px 0}
.org-level{display:flex;justify-content:center;gap:24px;position:relative}
.org-node{background:var(--surface);border:1.5px solid var(--border);border-radius:10px;padding:14px 18px;text-align:center;min-width:130px;box-shadow:var(--shadow-sm);transition:box-shadow .2s,transform .15s;cursor:default}
.org-node:hover{box-shadow:var(--shadow);transform:translateY(-2px)}
.org-node.top{border-color:var(--primary);background:var(--primary-light)}
.org-node.mid{border-color:var(--border)}
.org-connector{width:2px;height:28px;background:var(--border);margin:0 auto}
.org-h-line{height:2px;background:var(--border);margin:0 -12px}
.org-level-wrap{display:flex;flex-direction:column;align-items:center}
.org-name{font-family:var(--display);font-size:12.5px;font-weight:700;color:var(--ink)}
.org-role{font-size:11px;color:var(--ink3);margin-top:2px}
.org-dept{font-size:10px;font-weight:600;color:var(--primary);background:var(--primary-light);padding:2px 7px;border-radius:4px;margin-top:5px;display:inline-block}

/* ═══ SECTION HEADER ═══ */
.sh{padding:24px 28px 0;display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap}
.sey{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--primary);margin-bottom:4px}
.sti{font-family:var(--display);font-size:22px;font-weight:800;color:var(--ink);letter-spacing:-.5px}
.sde{font-size:13.5px;color:var(--ink3);margin-top:4px}
.sa{display:flex;gap:8px;align-items:center;flex-wrap:wrap}

/* ═══ HOME ═══ */
#homeContent{flex:1;display:flex;flex-direction:column;overflow-y:auto}
#newTicketContent{flex:1;overflow-y:auto}
#adminContent{flex:1;display:flex;flex-direction:column;overflow-y:auto}

/* ═══ PULSE ANIMATION ═══ */
@keyframes dot-pulse{0%,100%{box-shadow:0 0 0 0 rgba(180,83,9,.5)}50%{box-shadow:0 0 0 4px rgba(180,83,9,0)}}
.dot-pulse{animation:dot-pulse 2s infinite}

/* ═══ EMPTY ═══ */
.empty{text-align:center;padding:48px 20px;color:var(--ink3)}
.empty .ei{font-size:36px;margin-bottom:12px}
.empty h3{font-size:15px;color:var(--ink2);font-weight:600;margin-bottom:5px}

/* ═══ MISC ═══ */
.divider{height:1px;background:var(--border)}
</style>

</head>
<body>
<nav id="mainNav">
  <a class="nav-brand" href="home.php">
    <div class="nav-logo">DC</div>
    <span class="nav-name">DECOMOBIL</span>
  </a>
  <div class="nav-sep"></div>
  <div id="navLinks">
    <a class="nav-link active" href="home.php">🏠 Inicio</a>
    <a class="nav-link" href="new.php">🎫 Nuevo Ticket</a>
    <a class="nav-link" href="company.php">🏢 Nosotros</a>
    <a class="nav-link" href="org.php">🗂 Organigrama</a>
    <a class="nav-link" href="admin.php" data-role="agent">⚙️ Administración</a>
    <a class="nav-link" href="users.php" data-role="admin">👥 Usuarios</a>
    <a class="nav-link" href="metrics.php" data-role="admin">📊 Métricas</a>
  </div>
  <div id="navRight"></div>
</nav>
<div id="detailPanel"></div>
<div class="page">
<div id="homeContent" style="flex:1;display:flex;flex-direction:column;overflow-y:auto;padding-top:60px;margin:auto"></div>
</div>

<div id="toastContainer"></div>
<script>
/* ══ HELPERS ══ */
/* ══ HELPERS ══ */
const $ = id => document.getElementById(id);
const $$ = s => document.querySelectorAll(s);
const getInitials = (name) => String(name||'').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();

function formatDate(d) {
  if (!d) return '—';
  let dateString = String(d).trim();
  
  // Soporta YYYY-MM-DD, YYYY-MM-DD HH:MM:SS y marcas de tiempo ISO
  if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(dateString)) {
    dateString = dateString.replace(' ', 'T');
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
    dateString = `${dateString}T12:00:00`;
  }
  const dt = new Date(dateString);
  if (Number.isNaN(dt.getTime())) return '—';
  const m  = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
  return `${dt.getDate()} ${m[dt.getMonth()]} ${dt.getFullYear()}`;
}

function isOverdue(due, status) {
  if (!due || status === 'Resuelto') return false;
  const dateString = String(due).trim().replace(' ', 'T');
  const dt = new Date(dateString);
  if (Number.isNaN(dt.getTime())) return false;
  return dt < new Date();
}


function priorityBadge(p) {
  const styles = {
    'Critica': { bg: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.3)', color: '#dc2626', icon: '‼️' },
    'Alta': { bg: 'rgba(245, 101, 101, 0.1)', border: '1px solid rgba(245, 101, 101, 0.3)', color: '#ea580c', icon: '🔴' },
    'Media': { bg: 'rgba(251, 191, 36, 0.1)', border: '1px solid rgba(251, 191, 36, 0.3)', color: '#d97706', icon: '🟡' },
    'Baja': { bg: 'rgba(34, 197, 94, 0.1)', border: '1px solid rgba(34, 197, 94, 0.3)', color: '#16a34a', icon: '🟢' }
  };
  const style = styles[p] || styles['Baja'];
  return `<span class="badge" style="background:${style.bg};border:${style.border};color:${style.color}">${style.icon} ${p}</span>`;
}

function statusBadge(s) {
  const m={'Abierto':'b-open','En Progreso':'b-progress','En Revisión':'b-review','Pendiente':'b-pending','Resuelto':'b-resolved'};
  const dotC={'Abierto':'var(--primary)','En Progreso':'var(--amber)','En Revisión':'var(--violet)','Pendiente':'var(--ink3)','Resuelto':'var(--green)'};
  const pulse = s==='En Progreso'?' dot-pulse':'';
  return `<span class="badge ${m[s]||'b-pending'}"><span class="bd${pulse}" style="background:${dotC[s]||'var(--ink3)'}"></span>${s}</span>`;
}

function roleBadge(r) {
  const m={admin:['b-critical','👑 Admin'],agent:['b-progress','🛠 Agente'],user:['b-open','👤 Usuario']};
  const [c,l] = m[r]||['b-pending','Desconocido'];
  return `<span class="badge ${c}">${l}</span>`;
}

function showToast(msg, type='', icon='') {
  const c=$('toastContainer'); const icons={success:'✓',error:'✕'};
  const el=document.createElement('div'); el.className=`toast ${type}`;
  el.innerHTML=`<span style="font-size:15px">${icon||icons[type]||'ℹ'}</span><span>${msg}</span>`;
  c.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transform='translateX(20px) scale(.95)'; el.style.transition='all .3s'; setTimeout(()=>el.remove(),300); },3200);
}

function openModal(id)  { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }


//!gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg
(function initNav() {
  // Obtener sesión del nuevo sistema (sessionStorage)
  const sessionData = sessionStorage.getItem('user_session');
  const authToken = sessionStorage.getItem('auth_token');
  
  // Si no hay sesión válida, redirigir a login
  if (!sessionData || !authToken) { 
    window.location.href = 'login.php'; 
    return; 
  }
  
  const s = JSON.parse(sessionData);
  
  // Hide role-restricted links
  document.querySelectorAll('[data-role]').forEach(el => {
    const r = el.dataset.role;
    const ok = (r === 'agent' && (s.role==='agent'||s.role==='admin')) ||
               (r === 'admin' && s.role==='admin');
    if (!ok) el.style.display = 'none';
  });
  
  // User pill
  document.getElementById('navRight').innerHTML = `
    <div class="nav-user">
      <div class="avatar" style="width:28px;height:28px;background:${s.avatar};font-size:10px">${getInitials(s.name)}</div>
      <span style="font-size:13px;font-weight:600;color:rgba(255,255,255,.85)">${s.name.split(' ')[0]}</span>
    </div>
    <button class="nav-btn nb-ghost" onclick="sessionStorage.removeItem('auth_token');sessionStorage.removeItem('user_session');window.location.href='login.php'">Salir</button>
  `;
})();


document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.getElementById('detailPanel')?.classList.remove('open');
    document.querySelectorAll('.overlay').forEach(o => o.classList.remove('open'));
  }
});


/* ══ HOME ══ */
async function renderHome() {
  const API_BASE = new URL('../xampp_project/api', window.location.href).href;
  
  // Obtener sesión de sessionStorage  
  const sessionData = sessionStorage.getItem('user_session');
  const authToken = sessionStorage.getItem('auth_token');
  
  if (!sessionData || !authToken) {
    window.location.href = 'login.php';
    return;
  }
  
  const s = JSON.parse(sessionData);
  const isAgent = s.role === 'agent' || s.role === 'admin';
  
  try {
    // Obtener estadísticas
    const statsRes = await fetch(`${API_BASE}/tickets.php?stats=1`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });
    const statsData = await statsRes.json();
    const stats = statsData.data || {};
    
    // Obtener tickets
    const ticketsRes = await fetch(`${API_BASE}/tickets.php`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });
    const ticketsData = await ticketsRes.json();
    const tickets = (ticketsData.data || []).filter(t => !t.resolved_at || t.status !== 'Resuelto');
    const allTickets = ticketsData.data || [];
    const recent = allTickets.slice(0, 5);
    
    // Calcular estadísticas desde los datos
    const total = stats.total || 0;
    const open = (stats.by_status && stats.by_status['Abierto']) || 0;
    const inProgress = (stats.by_status && stats.by_status['En Progreso']) || 0;
    const resolved = (stats.by_status && stats.by_status['Resuelto']) || 0;
    const avgDays = stats.avg_resolution_days || 0;
    
    // Saludo según la hora
    const h = new Date().getHours();
    const greeting = h < 12 ? 'Buenos días' : h < 18 ? 'Buenas tardes' : 'Buenas noches';
    
    const homeContent = document.getElementById('homeContent');
    if (!homeContent) return;
    
    homeContent.innerHTML = `
      <div style="background:linear-gradient(135deg,#0E1117 0%,#0F52BA 100%);padding:32px 28px 28px;color:#fff;position:relative;overflow:hidden;flex-shrink:0">
        <div style="position:absolute;inset:0;background:radial-gradient(circle at 80% 50%,rgba(255,255,255,.05),transparent 60%);pointer-events:none"></div>
        <div style="position:relative">
          <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,.45);margin-bottom:8px">${new Date().toLocaleDateString('es-MX',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}</div>
          <h1 style="font-family:var(--display);font-size:26px;font-weight:800;letter-spacing:-.5px;margin-bottom:6px">${greeting}, ${s.name.split(' ')[0]} 👋</h1>
          <p style="font-size:13.5px;color:rgba(255,255,255,.6)">${s.role==='admin'?'Panel de administración completo — tienes acceso a todas las funciones.':'Gestiona tus tickets y mantén al equipo informado.'}</p>
        </div>
      </div>
      <div style="padding:20px 28px 0">
        <div class="stats-grid">
          <div class="stat-card sc-blue"><div class="sv">${total}</div><div class="sl">Total tickets</div><div class="ss">Histórico completo</div></div>
          <div class="stat-card sc-red"><div class="sv" style="color:var(--red)">${open}</div><div class="sl">Abiertos</div><div class="ss">Esperando atención</div></div>
          <div class="stat-card sc-amber"><div class="sv" style="color:var(--amber)">${inProgress}</div><div class="sl">En progreso</div><div class="ss">Siendo atendidos</div></div>
          <div class="stat-card sc-green"><div class="sv" style="color:var(--green)">${resolved}</div><div class="sl">Resueltos</div><div class="ss">Prom: ${avgDays} días</div></div>
        </div>
      </div>
      <div style="padding:20px 28px;display:grid;grid-template-columns:1fr 1fr;gap:20px;flex:1;min-height:0">
        <div class="card" style="overflow-y:auto">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
            <div class="ct" style="margin:0">Tickets activos</div>
            <button class="btn btn-sm btn-primary" onclick="navigate('new')">+ Nuevo</button>
          </div>
          ${tickets.length===0?`<div class="empty"><div class="ei">🎉</div><h3>Sin tickets activos</h3><p>No tienes pendientes.</p></div>`:
            tickets.slice(0,8).map(t=>`<div onclick="openDetail('${t.id}')" style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--border);cursor:pointer;border-radius:4px;padding-left:4px;transition:background .1s" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
              <div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:600;color:var(--ink);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${t.title}</div><div style="font-size:11px;color:var(--ink3);margin-top:2px;font-family:var(--mono)">${t.id} · ${formatDate(t.created_at)}</div></div>
              ${statusBadge(t.status)}
            </div>`).join('')}
        </div>
       ${isAgent?`<div class="card" style="overflow-y:auto">
          <div class="ct">Actividad reciente</div>
          ${recent.map(t=>`<div onclick="openDetail('${t.id}')" style="display:flex;align-items:flex-start;gap:10px;padding:9px 0;border-bottom:1px solid var(--border);cursor:pointer;border-radius:4px;padding-left:4px;transition:background .1s" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
            <div class="avatar" style="width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:10px;background:${t.assignee_avatar||'#9CA3AF'};color:#fff">${t.assignee_name?getInitials(t.assignee_name):'?'}</div>
            <div style="flex:1;min-width:0"><div style="font-size:12.5px;font-weight:600;color:var(--ink);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${t.title}</div>
            <div style="display:flex;gap:6px;margin-top:3px;align-items:center">${priorityBadge(t.priority)}<span style="font-size:11px;color:var(--ink4)">${formatDate(t.created_at)}</span></div></div>
          </div>`).join('')}
        </div>`:''}
      </div>`;
  } catch (error) {
    console.error('Error cargando datos:', error);
    document.getElementById('homeContent').innerHTML = `
      <div style="padding:40px 28px;text-align:center;color:var(--ink3)">
        <h3>Error cargando datos</h3>
        <p>No se pudieron obtener las estadísticas de la base de datos.</p>
      </div>`;
  }
}
/* ══ DETAIL PANEL ══ */
let activeDetailId=null;

async function openDetail(id) {
  const API_BASE = new URL('../xampp_project/api', window.location.href).href;
  const authToken = sessionStorage.getItem('auth_token');
  
  console.log('openDetail', id, 'API_BASE=', API_BASE);
  
  if (!authToken) {
    console.error('No hay token de autenticación');
    return;
  }
  
  try {
    const requestUrl = `${API_BASE}/tickets.php?id=${encodeURIComponent(id)}`;
    console.log('Fetching ticket URL:', requestUrl);
    const response = await fetch(requestUrl, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });
    
    const json = await response.json();
    console.log('Ticket response', response.status, json);
    if (!response.ok || !json.success || !json.data) {
      console.error('Error al cargar ticket', response.status, json);
      const message = json?.error || `Error ${response.status} al cargar el ticket`;
      $('detailPanel').innerHTML = `<div style="padding:20px;color:var(--red);font-weight:700">${message}</div>`;
      showToast(message, 'error');
      return;
    }
    
    const t = json.data;
    activeDetailId = id;
    
    // Obtener sesión actual
    const sessionData = sessionStorage.getItem('user_session');
    const userSession = sessionData ? JSON.parse(sessionData) : null;
    const isAgent = userSession && (userSession.role === 'agent' || userSession.role === 'admin');
    
    // Datos del ticket
    const activity = Array.isArray(t.activity) ? t.activity : [];
    const assigneeName = t.assignee_name || t.assignee || null;
    const creatorName = t.creator_name || t.creator || 'Sistema';
    const createdAt = formatDate(t.created_at || t.createdAt);
    const description = t.description || t.desc || '<em style="color:var(--ink4)">Sin descripción.</em>';
    
    // Función para renderizar actividad
    const renderActivity = (a) => {
      const type = a.type || a.activity_type || 'comment';
      const user = a.user_name || a.user || a.author || 'Sistema';
      const msg = a.msg || a.message || a.text || '';
      const time = a.time || formatTime(a.created_at || a.timestamp || new Date().toISOString());
      const icon = type === 'comment' ? '💬' : type === 'status' ? '🔄' : type === 'assign' ? '👤' : '✨';
      const bg = type === 'comment' ? 'var(--primary-light)' : type === 'status' ? 'var(--amber-light)' : 'var(--green-light)';
      return `
        <div style="display:flex;gap:10px;padding:9px 0;border-bottom:1px solid var(--border)">
          <div style="width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:11px;flex-shrink:0;background:${bg}">${icon}</div>
          <div style="flex:1"><div style="font-size:12.5px"><strong>${user}</strong> — ${msg}</div><div style="font-size:10.5px;color:var(--ink3);font-family:var(--mono);margin-top:2px">${time}</div></div>
        </div>`;
    };
    
    // Función auxiliar para formatear tiempo
    function formatTime(dateStr) {
      if (!dateStr) return '';
      const dt = new Date(dateStr);
      if (Number.isNaN(dt.getTime())) return '';
      return dt.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
    }
    
    $('detailPanel').innerHTML = `
      <div style="padding:16px 18px;border-bottom:1px solid var(--border);display:flex;align-items:flex-start;gap:12px;flex-shrink:0">
        <div style="flex:1;min-width:0">
          <div style="font-family:var(--mono);font-size:11px;color:var(--ink3);margin-bottom:5px">${t.id} · ${t.category || 'General'} · ${t.dept || 'N/D'}</div>
          <div style="font-family:var(--display);font-size:15px;font-weight:700;color:var(--ink);line-height:1.35">${t.title}</div>
          <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">${statusBadge(t.status)} ${priorityBadge(t.priority)}</div>
        </div>
        <div style="width:28px;height:28px;border-radius:6px;display:grid;place-items:center;cursor:pointer;color:var(--ink3);flex-shrink:0" onclick="$('detailPanel').classList.remove('open')" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">✕</div>
      </div>
      <div style="flex:1;overflow-y:auto;padding:16px 18px;display:flex;flex-direction:column;gap:16px">
        <div>
          <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:8px">Descripción</div>
          <div style="font-size:13px;color:var(--ink2);line-height:1.65;background:var(--bg);border:1px solid var(--border);border-radius:7px;padding:12px 14px">${description}</div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <div>
            <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:5px">Asignado a</div>
            <div style="display:flex;align-items:center;gap:7px">
              ${assigneeName ? `<div class="avatar" style="width:22px;height:22px;background:${t.assignee_avatar || '#9CA3AF'};font-size:9px">${getInitials(assigneeName)}</div>` : `<div class="avatar" style="width:22px;height:22px;background:var(--border2);border:1.5px dashed var(--border2)"></div>`}
              <span style="font-size:13px">${assigneeName || '<em style="color:var(--ink3)">Sin asignar</em>'}</span>
            </div>
          </div>
          <div>
            <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:5px">Reportado por</div>
            <div style="display:flex;align-items:center;gap:7px">
              ${creatorName !== 'Sistema' ? `<div class="avatar" style="width:22px;height:22px;background:${t.creator_avatar || '#9CA3AF'};font-size:9px">${getInitials(creatorName)}</div>` : ''}
              <span style="font-size:13px">${creatorName}</span>
            </div>
          </div>
          <div>
            <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:4px">Creado</div>
            <div style="font-size:13px">${createdAt}</div>
          </div>
          <div>
            <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:4px">Estado</div>
            <div style="font-size:13px">${t.status}</div>
          </div>
        </div>
        ${activity.length > 0 ? `
          <div>
            <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:8px">Actividad</div>
            <div style="background:var(--bg);border:1px solid var(--border);border-radius:7px;padding:12px 14px;max-height:200px;overflow-y:auto">
              ${activity.map(renderActivity).join('')}
            </div>
          </div>
        ` : ''}
        <div style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px">
          <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:10px">Añadir comentario</div>
          <div style="display:flex;gap:8px">
            <input type="text" id="dp-cmt" class="fi" style="flex:1" placeholder="Escribe un comentario..." maxlength="200">
            <button class="btn btn-sm btn-primary" onclick="addCmt('${t.id}')">Enviar</button>
          </div>
        </div>
        ${isAgent ? `
          <div style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px">
            <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:10px">Acciones rápidas</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              <button class="btn btn-sm btn-primary" onclick="changeStatus('${t.id}', 'En Progreso')">Marcar en progreso</button>
              <button class="btn btn-sm btn-success" onclick="changeStatus('${t.id}', 'Resuelto')">Marcar resuelto</button>
              <button class="btn btn-sm btn-ghost" onclick="assignToMe('${t.id}')">Asignarme</button>
              <button class="btn btn-sm btn-danger" onclick="deleteTicket('${t.id}')">🗑️ Eliminar</button>
            </div>
          </div>
        ` : ''}
      </div>`;
    
    $('detailPanel').classList.add('open');
    
  } catch (error) {
    console.error('Error cargando detalle del ticket:', error);
    showToast('Error al cargar el ticket', 'error');
  }
}

async function changeStatus(id, status) {
  const API_BASE = '../xampp_project/api';
  const authToken = sessionStorage.getItem('auth_token');
  
  if (!authToken) {
    console.error('No hay token de autenticación');
    return;
  }
  
  try {
    const response = await fetch(`${API_BASE}/tickets.php`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({
        id: id,
        status: status
      })
    });
    
    const json = await response.json();
    if (json.success) {
      openDetail(id);
      renderHome(); // Actualizar la lista de tickets activos
      showToast(`Estado: ${status}`, 'success');
    } else {
      console.error('Error cambiando estado:', json);
      showToast('Error al cambiar estado', 'error');
    }
  } catch (error) {
    console.error('Error cambiando estado:', error);
    showToast('Error al cambiar estado', 'error');
  }
}

async function assignToMe(id) {
  const API_BASE = '../xampp_project/api';
  const authToken = sessionStorage.getItem('auth_token');
  const sessionData = sessionStorage.getItem('user_session');
  const userSession = sessionData ? JSON.parse(sessionData) : null;
  
  if (!authToken || !userSession) {
    console.error('No hay token de autenticación o sesión');
    return;
  }
  
  try {
    const response = await fetch(`${API_BASE}/tickets.php`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({
        id: id,
        assignee_id: userSession.id
      })
    });
    
    const json = await response.json();
    if (json.success) {
      openDetail(id);
      renderHome(); // Actualizar la lista de tickets
      showToast('Ticket asignado a ti', 'success');
    } else {
      console.error('Error asignando ticket:', json);
      showToast('Error al asignar ticket', 'error');
    }
  } catch (error) {
    console.error('Error asignando ticket:', error);
    showToast('Error al asignar ticket', 'error');
  }
}

async function addCmt(id) {
  const txt = document.getElementById('dp-cmt')?.value.trim();
  if (!txt) return;
  
  const API_BASE = '../xampp_project/api';
  const authToken = sessionStorage.getItem('auth_token');
  const sessionData = sessionStorage.getItem('user_session');
  const userSession = sessionData ? JSON.parse(sessionData) : null;
  
  if (!authToken || !userSession) {
    console.error('No hay token de autenticación o sesión');
    return;
  }
  
  try {
    const response = await fetch(`${API_BASE}/activity.php`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      },
      body: JSON.stringify({
        ticket_id: id,
        user_name: userSession.name,
        type: 'comment',
        message: txt
      })
    });
    
    const json = await response.json();
    if (json.success) {
      document.getElementById('dp-cmt').value = ''; // Limpiar textarea
      openDetail(id); // Recargar detalles
      showToast('Comentario agregado', 'success');
    } else {
      console.error('Error agregando comentario:', json);
      showToast('Error al agregar comentario', 'error');
    }
  } catch (error) {
    console.error('Error agregando comentario:', error);
    showToast('Error al agregar comentario', 'error');
  }
}

async function deleteTicket(id) {
  // Confirmación para evitar accidentes
  if (!confirm('¿Estás seguro de que deseas eliminar este ticket?')) return;

  const API_BASE = '../xampp_project/api';
  const authToken = sessionStorage.getItem('auth_token');

  try {
    // IMPORTANTE: Tu PHP usa $_GET['id'], así que lo pasamos en la URL
    const response = await fetch(`${API_BASE}/tickets.php?id=${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${authToken}`
      }
    });

    const json = await response.json();

    if (json.success) {
      showToast(json.message || 'Ticket eliminado', 'success');
      // Cerramos el panel de detalles
      $('detailPanel').classList.remove('open');
      // Recargamos la lista del home para que desaparezca el ticket borrado
      renderHome();
    } else {
      // Aquí mostramos el error específico que configuraste en el PHP (400, 404, etc.)
      showToast(json.error || 'Error al eliminar', 'error');
    }
  } catch (error) {
    console.error('Error:', error);
    showToast('No se pudo conectar con el servidor', 'error');
  }
}

window.addEventListener('DOMContentLoaded', () => renderHome());

// Función de navegación
function navigate(page) {
  switch(page) {
    case 'new':
      window.location.href = 'new.php';
      break;
    case 'home':
      window.location.href = 'home.php';
      break;
    default:
      console.error('Página no reconocida:', page);
  }
}

</script>
</body>
</html>