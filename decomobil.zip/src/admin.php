<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Administración — Decomobil</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root {
  --ink:#0E1117; --ink2:#374151; --ink3:#6B7280; --ink4:#9CA3AF;
  --bg:#F7F8FA; --bg2:#EDEEF1;
  --surface:#FFFFFF; --surface2:#F9FAFB;
  --border:#E5E7EB; --border2:#D1D5DB;
  --primary:#0F52BA; --primary-dark:#0A3D8F; --primary-light:#EBF0FB;
  --red:#C0392B; --red-light:#FEF2F2;
  --amber:#B45309; --amber-light:#FFFBEB;
  --green:#15803D; --green-light:#F0FDF4;
  --violet:#6D28D9; --violet-light:#F5F3FF;
  --teal:#0D9488;
  --display:'Arial'; --body:'Arial'; --mono:'Arial';
  --radius:10px; --radius-sm:6px; --radius-lg:16px;
  --shadow-sm:0 1px 4px rgba(0,0,0,.08); --shadow:0 4px 16px rgba(0,0,0,.10); --shadow-lg:0 20px 48px rgba(0,0,0,.15);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--body);background:var(--bg);color:var(--ink);-webkit-font-smoothing:antialiased;min-height:100vh}
a{color:inherit;text-decoration:none}
button{font-family:var(--body);cursor:pointer;border:none;background:none}
input,select,textarea{font-family:var(--body)}
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:3px}

#mainNav{position:fixed;top:0;left:0;right:0;height:60px;background:#0E1117;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;padding:0 24px;z-index:1000;gap:0}
.nav-brand{display:flex;align-items:center;gap:10px;color:#fff;flex-shrink:0;text-decoration:none}
.nav-logo{width:32px;height:32px;background:var(--primary);border-radius:8px;display:grid;place-items:center;font-family:var(--display);font-size:13px;font-weight:800;color:#fff}
.nav-name{font-family:var(--display);font-size:18px;font-weight:700;color:#fff;letter-spacing:-.3px}
.nav-sep{width:1px;height:22px;background:rgba(255,255,255,.1);margin:0 18px}
#navLinks{display:flex;align-items:center;gap:2px;flex:1}
.nav-link{display:flex;align-items:center;gap:6px;padding:6px 12px;border-radius:7px;font-size:13px;font-weight:500;color:rgba(255,255,255,.55);cursor:pointer;transition:all .15s;white-space:nowrap;border:1px solid transparent}
.nav-link:hover{color:#fff;background:rgba(255,255,255,.07)}
.nav-link.active{color:#fff;background:rgba(255,255,255,.10);border-color:rgba(255,255,255,.12);font-weight:600}
#navRight{display:flex;align-items:center;gap:8px;margin-left:auto}
.nav-user{display:flex;align-items:center;gap:8px;padding:4px 12px 4px 4px;border-radius:20px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);cursor:pointer}
.nav-user:hover{background:rgba(255,255,255,.12)}
.nav-btn{height:32px;padding:0 14px;border-radius:7px;font-size:12.5px;font-weight:600;display:inline-flex;align-items:center;gap:6px;cursor:pointer;transition:all .15s}
.nb-ghost{border:1px solid rgba(255,255,255,.2);color:rgba(255,255,255,.65)}
.nb-ghost:hover{background:rgba(255,255,255,.08);color:#fff}

.page{padding-top:60px;min-height:100vh;display:flex;flex-direction:column}

.btn{display:inline-flex;align-items:center;gap:7px;height:36px;padding:0 18px;border-radius:var(--radius-sm);font-size:13.5px;font-weight:600;cursor:pointer;transition:all .15s;border:1.5px solid transparent;white-space:nowrap;font-family:var(--body)}
.btn-sm{height:30px;padding:0 12px;font-size:12px}
.btn-primary{background:var(--primary);color:#fff;border-color:var(--primary)}
.btn-primary:hover{background:var(--primary-dark)}
.btn-ghost{border-color:var(--border2);color:var(--ink2);background:var(--surface)}
.btn-ghost:hover{background:var(--bg)}
.btn-danger{background:var(--red);color:#fff}
.btn-danger:hover{background:#a93226}

.fs{width:100%;border:1.5px solid var(--border);border-radius:var(--radius-sm);padding:8px 11px;font-size:13.5px;color:var(--ink);background:var(--surface);outline:none;font-family:var(--body)}
.fs:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(15,82,186,.12)}

.badge{display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:5px;font-size:11.5px;font-weight:600;white-space:nowrap}
.bd{width:5px;height:5px;border-radius:50%;flex-shrink:0}
.b-open{background:var(--primary-light);color:var(--primary)}
.b-progress{background:var(--amber-light);color:var(--amber)}
.b-review{background:var(--violet-light);color:var(--violet)}
.b-pending{background:var(--bg2);color:var(--ink3);border:1px solid var(--border)}
.b-resolved{background:var(--green-light);color:var(--green)}
.b-critical{background:#2D1B6B;color:#C4B5FD}
.b-high{background:var(--red-light);color:var(--red)}
.b-medium{background:var(--amber-light);color:var(--amber)}
.b-low{background:var(--green-light);color:var(--green)}

.overlay{position:fixed;inset:0;background:rgba(14,17,23,.55);backdrop-filter:blur(3px);z-index:2000;display:none;align-items:center;justify-content:center;padding:20px}
.overlay.open{display:flex;animation:fade-in .2s ease}
@keyframes fade-in{from{opacity:0}to{opacity:1}}
.modal{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);width:100%;max-width:560px;max-height:calc(100vh - 40px);display:flex;flex-direction:column;overflow:hidden;animation:modal-in .25s cubic-bezier(.34,1.4,.64,1)}
@keyframes modal-in{from{opacity:0;transform:scale(.94) translateY(8px)}to{opacity:1;transform:scale(1) translateY(0)}}
.mh{padding:18px 20px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.mt{font-family:var(--display);font-size:15px;font-weight:700;color:var(--ink)}
.mc{width:28px;height:28px;border-radius:6px;display:grid;place-items:center;color:var(--ink3);cursor:pointer;transition:all .12s}
.mc:hover{background:var(--bg)}
.mb{padding:20px;overflow-y:auto;display:flex;flex-direction:column;gap:14px;flex:1}
.mf{padding:14px 20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px;background:var(--surface2);flex-shrink:0}

#toastContainer{position:fixed;bottom:20px;right:20px;display:flex;flex-direction:column-reverse;gap:8px;z-index:9999;pointer-events:none}
.toast{display:flex;align-items:center;gap:10px;padding:11px 16px;border-radius:var(--radius-sm);font-size:13.5px;font-weight:500;color:#fff;box-shadow:var(--shadow);min-width:240px;max-width:340px;animation:toast-in .3s cubic-bezier(.34,1.4,.64,1);pointer-events:auto;background:var(--ink)}
.toast.success{background:#166534} .toast.error{background:#991b1b} .toast.warning{background:#92400e}
@keyframes toast-in{from{opacity:0;transform:translateX(20px) scale(.95)}to{opacity:1;transform:translateX(0) scale(1)}}

.dt{width:100%;border-collapse:collapse}
.dt th{padding:10px 14px;text-align:left;font-size:10.5px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;color:var(--ink3);background:var(--surface2);border-bottom:1px solid var(--border);white-space:nowrap}
.dt td{padding:11px 14px;font-size:13px;color:var(--ink2);border-bottom:1px solid var(--border);vertical-align:middle}
.dt tr:last-child td{border-bottom:none}
.dt tr:hover td{background:var(--surface2)}
.dt tr{transition:background .1s;cursor:pointer}

#detailPanel{position:fixed;top:60px;right:0;bottom:0;width:460px;background:var(--surface);border-left:1px solid var(--border);box-shadow:-8px 0 32px rgba(0,0,0,.08);z-index:900;display:none;flex-direction:column;overflow:hidden}
#detailPanel.open{display:flex;animation:panel-in .22s ease}
@keyframes panel-in{from{transform:translateX(20px);opacity:0}to{transform:translateX(0);opacity:1}}

.avatar{border-radius:50%;display:grid;place-items:center;font-weight:700;color:#fff;flex-shrink:0}

.sh{padding:24px 28px 0;display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap}
.sey{font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--primary);margin-bottom:4px}
.sti{font-family:var(--display);font-size:22px;font-weight:800;color:var(--ink);letter-spacing:-.5px}
.sde{font-size:13.5px;color:var(--ink3);margin-top:4px}

#adminContent{flex:1;display:flex;flex-direction:column;overflow-y:auto;width:100%;max-width:1400px;margin:0 auto}

@keyframes dot-pulse{0%,100%{box-shadow:0 0 0 0 rgba(180,83,9,.5)}50%{box-shadow:0 0 0 4px rgba(180,83,9,0)}}
.dot-pulse{animation:dot-pulse 2s infinite}

.empty{text-align:center;padding:48px 20px;color:var(--ink3)}
.empty .ei{font-size:36px;margin-bottom:12px}
.empty h3{font-size:15px;color:var(--ink2);font-weight:600;margin-bottom:5px}
</style>
</head>
<body>
<nav id="mainNav">
  <a class="nav-brand" href="home.php">
    <div class="nav-logo">DC</div>
    <span class="nav-name">DECOMOBIL</span>
  </a>
  <div class="nav-sep"></div>
  <div id="navLinks">
    <a class="nav-link" href="home.php">🏠 Inicio</a>
    <a class="nav-link" href="new.php">🎫 Nuevo Ticket</a>
    <a class="nav-link" href="company.php">🏢 Nosotros</a>
    <a class="nav-link" href="org.php">🗂 Organigrama</a>
    <a class="nav-link active" href="admin.php" data-role="agent">⚙️ Administración</a>
    <a class="nav-link" href="users.php" data-role="admin">👥 Usuarios</a>
    <a class="nav-link" href="metrics.php" data-role="admin">📊 Métricas</a>
  </div>
  <div id="navRight"></div>
</nav>
<div id="detailPanel"></div>
<div class="page">
  <div id="adminContent"></div>
</div>

<div class="overlay" id="confirmTicketDelete" onclick="if(event.target===this)closeModal('confirmTicketDelete')">
  <div class="modal" style="max-width:380px">
    <div class="mh"><span class="mt">⚠ Eliminar ticket</span><div class="mc" onclick="closeModal('confirmTicketDelete')">✕</div></div>
    <div class="mb"><p style="font-size:13.5px;color:var(--ink2);line-height:1.6">¿Confirmas eliminar este ticket? Esta acción es permanente.</p></div>
    <div class="mf">
      <button class="btn btn-ghost" onclick="closeModal('confirmTicketDelete')">Cancelar</button>
      <button class="btn btn-danger" onclick="confirmTicketDelete()">Sí, eliminar</button>
    </div>
  </div>
</div>
<div id="toastContainer"></div>

<script>
/* ══════════════════════════════════════════════════════════
   CONFIG
   ══════════════════════════════════════════════════════════ */
const API_BASE = '../xampp_project/api'; // admin.php en /src , apis en /api (mismo nivel)

/* ══ HELPERS ══ */
const $  = id => document.getElementById(id);
const $$ = s  => document.querySelectorAll(s);
const getInitials = n => String(n||'').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();

function formatDate(d){
  if(!d) return '—';
  const raw = String(d).split(' ')[0];
  const dt = new Date(raw + 'T12:00:00');
  if(isNaN(dt)) return '—';
  const m = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];
  return `${dt.getDate()} ${m[dt.getMonth()]} ${dt.getFullYear()}`;
}
function isOverdue(due,status){
  if(!due || status==='Resuelto') return false;
  return new Date(String(due).split(' ')[0]) < new Date(new Date().toISOString().split('T')[0]);
}
function showToast(msg,type=''){
  const c=$('toastContainer');
  const icons={success:'✓',error:'✕',warning:'⚠'};
  const el=document.createElement('div'); el.className=`toast ${type}`;
  el.innerHTML=`<span style="font-size:15px">${icons[type]||'ℹ'}</span><span>${msg}</span>`;
  c.appendChild(el);
  setTimeout(()=>{el.style.opacity='0';el.style.transform='translateX(20px) scale(.95)';el.style.transition='all .3s';setTimeout(()=>el.remove(),300)},3200);
}
function openModal(id){ $(id).classList.add('open'); }
function closeModal(id){ $(id).classList.remove('open'); }

/* ══ SESIÓN ══ */
const Session = {
  get(){ try { return JSON.parse(sessionStorage.getItem('user_session')||'null'); } catch(e){ return null; } },
  token(){ return sessionStorage.getItem('auth_token'); },
  isAgent(){ const s=Session.get(); return s && (s.role==='agent'||s.role==='admin'); },
  isAdmin(){ const s=Session.get(); return s && s.role==='admin'; },
  clear(){ sessionStorage.removeItem('auth_token'); sessionStorage.removeItem('user_session'); }
};

/* ══ CLIENTE API ══ */
async function apiFetch(path, opts={}){
  const headers = { 'Content-Type':'application/json', ...(opts.headers||{}) };
  const tk = Session.token();
  if (tk) headers['Authorization'] = 'Bearer ' + tk;
  const res = await fetch(API_BASE + path, { ...opts, headers });
  let data = null;
  try { data = await res.json(); } catch(e){ data = { success:false, error:'Respuesta no válida' }; }
  if (!res.ok || data.success === false) {
    const err = (data && data.error) ? data.error : ('HTTP '+res.status);
    throw new Error(err);
  }
  return data;
}
const API = {
  listTickets: ()             => apiFetch('/tickets.php'),
  getTicket:   id             => apiFetch('/tickets.php?id=' + encodeURIComponent(id)),
  updateTicket:(id,payload)   => apiFetch('/tickets.php', { method:'PUT',    body: JSON.stringify({ id, ...payload }) }),
  deleteTicket:id             => apiFetch('/tickets.php?id=' + encodeURIComponent(id), { method:'DELETE' }),
  listUsers:   ()             => apiFetch('/users.php'),
  addActivity: payload        => apiFetch('/activity.php', { method:'POST', body: JSON.stringify(payload) }),
};

/* ══ NORMALIZACIÓN snake_case → camelCase ══ */
function normalizeTicket(t){
  return {
    id: t.id, title: t.title,
    desc: t.description ?? t.desc ?? '',
    priority: t.priority, status: t.status,
    category: t.category, dept: t.dept,
    assigneeId: t.assignee_id ?? t.assigneeId ?? null,
    createdBy:  t.created_by  ?? t.createdBy  ?? null,
    createdAt:  t.created_at  ?? t.createdAt  ?? null,
    dueDate:    t.due_date    ?? t.dueDate    ?? null,
    resolvedAt: t.resolved_at ?? t.resolvedAt ?? null,
    creatorName:  t.creator_name  ?? null,
    creatorAvatar:t.creator_avatar ?? null,
    assigneeName: t.assignee_name  ?? null,
    assigneeAvatar:t.assignee_avatar ?? null,
    activity: Array.isArray(t.activity) ? t.activity : []
  };
}

/* ══ CACHE ══ */
let TICKETS = [];
let USERS   = [];
let USERS_BY_ID = {};
function userById(id){ return USERS_BY_ID[id] || null; }

/* ══ BADGES ══ */
function priorityBadge(p){
  const m={'Crítica':['b-critical','🟣'],'Critica':['b-critical','🟣'],'Alta':['b-high','🔴'],'Media':['b-medium','🟡'],'Baja':['b-low','🟢']};
  const [c,i]=m[p]||['b-low','⚪']; return `<span class="badge ${c}">${i} ${p}</span>`;
}
function statusBadge(s){
  const m={'Abierto':'b-open','En Progreso':'b-progress','En Revisión':'b-review','En Revision':'b-review','Pendiente':'b-pending','Resuelto':'b-resolved'};
  const dotC={'Abierto':'var(--primary)','En Progreso':'var(--amber)','En Revisión':'var(--violet)','En Revision':'var(--violet)','Pendiente':'var(--ink3)','Resuelto':'var(--green)'};
  const pulse = s==='En Progreso' ? ' dot-pulse' : '';
  return `<span class="badge ${m[s]||'b-pending'}"><span class="bd${pulse}" style="background:${dotC[s]||'var(--ink3)'}"></span>${s}</span>`;
}
function avatarHTML(userId, size=24){
  const u = userById(userId);
  if(!u) return `<div class="avatar" style="width:${size}px;height:${size}px;background:var(--border2);font-size:${Math.floor(size*.38)}px">?</div>`;
  return `<div class="avatar" style="width:${size}px;height:${size}px;background:${u.avatar||'#0F52BA'};font-size:${Math.floor(size*.38)}px" title="${u.name}">${getInitials(u.name)}</div>`;
}

function computeStats(list){
  return {
    total:list.length,
    open:list.filter(t=>t.status==='Abierto').length,
    inProgress:list.filter(t=>t.status==='En Progreso').length,
    review:list.filter(t=>t.status==='En Revisión' || t.status==='En Revision').length,
    pending:list.filter(t=>t.status==='Pendiente').length,
    resolved:list.filter(t=>t.status==='Resuelto').length,
  };
}

/* ══ NAV + SESIÓN ══ */
(function initNav(){
  const s = Session.get();
  const tk = Session.token();
  if (!s || !tk) { window.location.href = 'login.php'; return; }
  document.querySelectorAll('[data-role]').forEach(el=>{
    const r = el.dataset.role;
    const ok = (r==='agent' && Session.isAgent()) || (r==='admin' && Session.isAdmin());
    if (!ok) el.style.display = 'none';
  });
  document.getElementById('navRight').innerHTML = `
    <div class="nav-user">
      <div class="avatar" style="width:28px;height:28px;background:${s.avatar||'#0F52BA'};font-size:10px">${getInitials(s.name)}</div>
      <span style="font-size:13px;font-weight:600;color:rgba(255,255,255,.85)">${(s.name||'').split(' ')[0]}</span>
    </div>
    <button class="nav-btn nb-ghost" id="logoutBtn">Salir</button>
  `;
  document.getElementById('logoutBtn').onclick = async () => {
    try { await fetch(API_BASE + '/auth.php?action=logout', { headers:{ 'Authorization':'Bearer '+Session.token() } }); } catch(e){}
    Session.clear();
    window.location.href = 'login.php';
  };
})();

document.addEventListener('keydown', e=>{
  if (e.key === 'Escape') {
    document.getElementById('detailPanel')?.classList.remove('open');
    document.querySelectorAll('.overlay').forEach(o=>o.classList.remove('open'));
  }
});

/* ══ ADMIN PANEL ══ */
let adminTab = 'all';
let pendingDelTicket = null;

window.addEventListener('DOMContentLoaded', async () => {
  if (!Session.isAgent()) { window.location.href = 'home.php'; return; }
  renderAdminShell();
  await reloadData();
});

async function reloadData(){
  try {
    const [uRes, tRes] = await Promise.all([ API.listUsers(), API.listTickets() ]);
    USERS = uRes.data || [];
    USERS_BY_ID = {}; USERS.forEach(u => USERS_BY_ID[u.id] = u);
    TICKETS = (tRes.data || []).map(normalizeTicket);
    setTab(adminTab);
  } catch(err){ showToast('Error al cargar datos: ' + err.message, 'error'); }
}

function renderAdminShell(){
  document.getElementById('adminContent').innerHTML = `
    <div class="sh">
      <div>
        <div class="sey">Panel de Control</div>
        <div class="sti">Administración de Tickets</div>
        <div class="sde">Gestiona, asigna y da seguimiento a todos los tickets del sistema.</div>
      </div>
    </div>
    <div style="padding:8px 28px 0;display:flex;gap:2px;border-bottom:1px solid var(--border);overflow-x:auto">
      ${[['all','Todos'],['open','Abiertos'],['progress','En Progreso'],['pending','Pendientes'],['resolved','Resueltos']].map(([k,l])=>
        `<div id="atab-${k}" onclick="setTab('${k}')"
          style="padding:10px 16px;font-size:13px;font-weight:600;cursor:pointer;border-bottom:2px solid transparent;white-space:nowrap;color:var(--ink3);transition:all .15s;display:flex;align-items:center;gap:6px">
          ${l}<span id="acnt-${k}" style="font-family:var(--mono);font-size:10px;background:var(--bg2);padding:1px 6px;border-radius:8px;color:var(--ink3)">0</span>
        </div>`
      ).join('')}
    </div>
    <div id="tabContent" style="flex:1;overflow-y:auto;padding:20px 28px"></div>`;
}

function setTab(tab){
  adminTab = tab;
  const stats = computeStats(TICKETS);
  ['all','open','progress','pending','resolved'].forEach(k=>{
    const el = $(`atab-${k}`); if(!el) return;
    el.style.color = k===tab ? 'var(--primary)' : 'var(--ink3)';
    el.style.borderBottomColor = k===tab ? 'var(--primary)' : 'transparent';
  });
  const cnt = { all: TICKETS.length, open: stats.open, progress: stats.inProgress, pending: stats.pending, resolved: stats.resolved };
  Object.entries(cnt).forEach(([k,v])=>{ const el=$(`acnt-${k}`); if(el) el.textContent=v; });
  const c = $('tabContent'); if(!c) return;
  const fm = { all:null, open:'Abierto', progress:'En Progreso', pending:'Pendiente', resolved:'Resuelto' };
  const f = fm[tab];
  const list = f ? TICKETS.filter(t=>t.status===f) : TICKETS.slice();
  renderTicketTable(c, list);
}

function renderTicketTable(container, list){
  container.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap">
      <div style="position:relative;flex:1;min-width:200px;max-width:300px">
        <span style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--ink3)">🔍</span>
        <input id="admSearch" style="width:100%;border:1.5px solid var(--border);border-radius:6px;padding:7px 10px 7px 30px;font-size:13px;outline:none;font-family:var(--body)" placeholder="Buscar tickets..." oninput="filterTTable()">
      </div>
      <select id="admPrio" style="height:34px;padding:0 10px;border:1.5px solid var(--border);border-radius:6px;font-size:12.5px;outline:none;font-family:var(--body)" onchange="filterTTable()"><option value="">Todas las prioridades</option><option>Crítica</option><option>Alta</option><option>Media</option><option>Baja</option></select>
      <select id="admCat"  style="height:34px;padding:0 10px;border:1.5px solid var(--border);border-radius:6px;font-size:12.5px;outline:none;font-family:var(--body)" onchange="filterTTable()"><option value="">Todas las categorías</option><option>TI</option><option>RRHH</option><option>OPS</option><option>CONT</option><option>VEN</option><option>INFRA</option><option>OTROS</option></select>
      <span id="tCountLabel" style="font-size:12px;color:var(--ink3);font-family:var(--mono);margin-left:auto">${list.length} tickets</span>
    </div>
    <div style="background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden">
      <table class="dt"><thead><tr><th>ID</th><th>TÍTULO</th><th>PRIORIDAD</th><th>ESTADO</th><th>ASIGNADO</th><th>CREADO</th><th></th></tr></thead>
      <tbody id="tBody">${tRows(list)}</tbody></table>
    </div>`;
}

function tRows(list){
  if (!list.length) return '<tr><td colspan="7"><div class="empty"><div class="ei">🎫</div><h3>Sin tickets</h3></div></td></tr>';
  return list.map(t=>{
    const ag = userById(t.assigneeId);
    return `<tr onclick="openDetail('${t.id}')">
      <td><span style="font-family:var(--mono);font-size:11px;color:var(--ink3)">${t.id}</span></td>
      <td style="max-width:300px"><div style="font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--ink)">${t.title}</div><div style="font-size:11px;color:var(--ink3)">${t.category||'—'} · ${t.dept||'—'}</div></td>
      <td>${priorityBadge(t.priority)}</td>
      <td>${statusBadge(t.status)}</td>
      <td><div style="display:flex;align-items:center;gap:6px">${t.assigneeId ? avatarHTML(t.assigneeId,20) : `<div style="width:20px;height:20px;border-radius:50%;border:1.5px dashed var(--border2)"></div>`}<span style="font-size:12px">${ag?ag.name.split(' ')[0]:(t.assigneeName?t.assigneeName.split(' ')[0]:'—')}</span></div></td>
      <td><span style="font-size:12px;color:var(--ink3)">${formatDate(t.createdAt)}</span></td>
      <td onclick="event.stopPropagation()"><button class="btn btn-sm btn-danger" onclick="askDelTicket('${t.id}')">✕</button></td>
    </tr>`;
  }).join('');
}

function filterTTable(){
  const q   = $('admSearch')?.value.toLowerCase() || '';
  const p   = $('admPrio')?.value || '';
  const cat = $('admCat')?.value  || '';
  const fm = { all:null, open:'Abierto', progress:'En Progreso', pending:'Pendiente', resolved:'Resuelto' };
  const f = fm[adminTab];
  let list = TICKETS.slice();
  if (f)   list = list.filter(t=>t.status===f);
  if (q)   list = list.filter(t => (t.title||'').toLowerCase().includes(q) || (t.id||'').toLowerCase().includes(q) || (t.dept||'').toLowerCase().includes(q));
  if (p)   list = list.filter(t=>t.priority===p);
  if (cat) list = list.filter(t=>t.category===cat);
  const b = $('tBody'); if (b) b.innerHTML = tRows(list);
  const cl = $('tCountLabel'); if (cl) cl.textContent = list.length + ' tickets';
}

/* ══ DELETE ══ */
function askDelTicket(id){ pendingDelTicket = id; openModal('confirmTicketDelete'); }
async function confirmTicketDelete(){
  if (!pendingDelTicket) return;
  const id = pendingDelTicket;
  try {
    await API.deleteTicket(id);
    $('detailPanel').classList.remove('open');
    closeModal('confirmTicketDelete');
    pendingDelTicket = null;
    TICKETS = TICKETS.filter(t=>t.id!==id);
    setTab(adminTab);
    showToast('Ticket eliminado', 'error');
  } catch(err){
    closeModal('confirmTicketDelete');
    pendingDelTicket = null;
    showToast('No se pudo eliminar: ' + err.message, 'error');
  }
}

/* ══ DETAIL ══ */
let activeDetailId = null;

async function openDetail(id){
  activeDetailId = id;
  try {
    const res = await API.getTicket(id);
    const t = normalizeTicket(res.data);
    renderDetail(t);
    const idx = TICKETS.findIndex(x=>x.id===id);
    if (idx >= 0) TICKETS[idx] = { ...TICKETS[idx], ...t };
  } catch(err){ showToast('No se pudo cargar el ticket: ' + err.message, 'error'); }
}

function renderDetail(t){
  const agents = USERS.filter(u => (u.role==='agent'||u.role==='admin') && String(u.active)!=='0');
  const isAgent = Session.isAgent();
  const creatorName = userById(t.createdBy)?.name || t.creatorName || 'Sistema';

  $('detailPanel').innerHTML = `
    <div style="padding:16px 18px;border-bottom:1px solid var(--border);display:flex;align-items:flex-start;gap:12px;flex-shrink:0">
      <div style="flex:1;min-width:0">
        <div style="font-family:var(--mono);font-size:11px;color:var(--ink3);margin-bottom:5px">${t.id} · ${t.category||'—'} · ${t.dept||'—'}</div>
        <div style="font-family:var(--display);font-size:15px;font-weight:700;color:var(--ink);line-height:1.35">${t.title}</div>
        <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">${statusBadge(t.status)} ${priorityBadge(t.priority)}</div>
      </div>
      <div style="width:28px;height:28px;border-radius:6px;display:grid;place-items:center;cursor:pointer;color:var(--ink3);flex-shrink:0" onclick="document.getElementById('detailPanel').classList.remove('open')">✕</div>
    </div>
    <div style="flex:1;overflow-y:auto;padding:16px 18px;display:flex;flex-direction:column;gap:16px">
      <div>
        <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:8px">Descripción</div>
        <div style="font-size:13px;color:var(--ink2);line-height:1.65;background:var(--bg);border:1px solid var(--border);border-radius:7px;padding:12px 14px">${t.desc || '<em style="color:var(--ink4)">Sin descripción.</em>'}</div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div>
          <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:5px">Asignado a</div>
          <div style="display:flex;align-items:center;gap:7px">${t.assigneeId?avatarHTML(t.assigneeId,22):`<div class="avatar" style="width:22px;height:22px;background:var(--border2);border:1.5px dashed var(--border2)"></div>`}<span style="font-size:13px">${t.assigneeId?(userById(t.assigneeId)?.name || t.assigneeName || '—'):'<em style="color:var(--ink3)">Sin asignar</em>'}</span></div>
        </div>
        <div>
          <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:5px">Reportado por</div>
          <div style="display:flex;align-items:center;gap:7px">${t.createdBy?avatarHTML(t.createdBy,22):''}<span style="font-size:13px">${creatorName}</span></div>
        </div>
        <div><div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:4px">Creado</div><div style="font-size:13px">${formatDate(t.createdAt)}</div></div>
        <div><div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:4px">Vence</div><div style="font-size:13px;color:${isOverdue(t.dueDate,t.status)?'var(--red)':'var(--ink2)'}">${formatDate(t.dueDate)}</div></div>
      </div>
      ${isAgent ? `
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px">
        <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:10px">Acciones rápidas</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px">
          ${['Abierto','En Progreso','En Revisión','Pendiente','Resuelto'].map(st =>
            `<button class="btn btn-sm ${t.status===st?'btn-primary':'btn-ghost'}" onclick="changeStatus('${t.id}','${st}')">${st}</button>`
          ).join('')}
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <select class="fs" id="dp-ass" style="flex:1;height:30px;font-size:12px;padding:0 8px">
            <option value="">Reasignar a...</option>
            ${agents.map(u=>`<option value="${u.id}" ${String(t.assigneeId)===String(u.id)?'selected':''}>${u.name}</option>`).join('')}
          </select>
          <button class="btn btn-sm btn-ghost" onclick="changeAssignee('${t.id}')">Asignar</button>
        </div>
      </div>` : ''}
      <div>
        <div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink3);margin-bottom:8px">Actividad (${t.activity.length})</div>
        ${t.activity.slice().reverse().map(a=>{
          const type = a.activity_type || a.type || 'comment';
          const msg  = a.message || a.msg || '';
          const user = a.user_name || a.user || 'Sistema';
          const when = a.created_at ? new Date(a.created_at.replace(' ','T')).toLocaleString('es-MX',{dateStyle:'short',timeStyle:'short'}) : (a.time||'');
          const bg   = type==='comment'?'var(--primary-light)': type==='status'?'var(--amber-light)':'var(--green-light)';
          const ic   = type==='comment'?'💬': type==='status'?'🔄': type==='assign'?'👤':'✨';
          return `<div style="display:flex;gap:10px;padding:9px 0;border-bottom:1px solid var(--border)">
            <div style="width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:11px;flex-shrink:0;background:${bg}">${ic}</div>
            <div style="flex:1"><div style="font-size:12.5px"><strong>${user}</strong> — ${msg}</div><div style="font-size:10.5px;color:var(--ink3);font-family:var(--mono);margin-top:2px">${when}</div></div>
          </div>`;
        }).join('')}
      </div>
      ${isAgent ? `<div style="display:flex;gap:8px"><button class="btn btn-sm btn-danger" onclick="askDelTicket('${t.id}')">🗑 Eliminar ticket</button></div>` : ''}
    </div>
    <div style="padding:12px 18px;border-top:1px solid var(--border);background:var(--surface2);flex-shrink:0">
      <div style="display:flex;gap:8px;align-items:flex-end">
        <textarea id="dp-cmt" placeholder="Agregar comentario... (Enter para enviar)" style="flex:1;border:1.5px solid var(--border);border-radius:7px;padding:8px 11px;font-size:12.5px;font-family:var(--body);outline:none;resize:none;min-height:36px;max-height:100px;line-height:1.5" onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();addCmt('${t.id}')}"></textarea>
        <button class="btn btn-primary btn-sm" onclick="addCmt('${t.id}')">Enviar</button>
      </div>
    </div>`;
  $('detailPanel').classList.add('open');
}

/* ══ ACCIONES ══ */
async function changeStatus(id, status){
  const s = Session.get();
  try {
    await API.updateTicket(id, { status, user_name: s?.name || 'Sistema' });
    showToast(`Estado: ${status}`, 'success');
    const res = await API.getTicket(id);
    const t = normalizeTicket(res.data);
    const idx = TICKETS.findIndex(x=>x.id===id); if (idx>=0) TICKETS[idx] = t;
    renderDetail(t);
    setTab(adminTab);
  } catch(err){ showToast('Error: ' + err.message, 'error'); }
}

async function changeAssignee(id){
  const sel = $('dp-ass'); if (!sel || !sel.value) return;
  const s = Session.get();
  const ag = userById(parseInt(sel.value));
  try {
    await API.updateTicket(id, { assignee_id: parseInt(sel.value), user_name: s?.name || 'Sistema' });
    showToast(`Asignado a ${ag?.name || 'usuario'}`, 'success');
    const res = await API.getTicket(id);
    const t = normalizeTicket(res.data);
    const idx = TICKETS.findIndex(x=>x.id===id); if (idx>=0) TICKETS[idx] = t;
    renderDetail(t);
    setTab(adminTab);
  } catch(err){ showToast('Error: ' + err.message, 'error'); }
}

async function addCmt(id){
  const ta = $('dp-cmt'); const txt = ta?.value.trim(); if (!txt) return;
  const s = Session.get();
  try {
    await API.addActivity({ ticket_id: id, user_name: s?.name || 'Tú', type: 'comment', message: txt });
    if (ta) ta.value = '';
    showToast('Comentario agregado', 'success');
    const res = await API.getTicket(id);
    const t = normalizeTicket(res.data);
    const idx = TICKETS.findIndex(x=>x.id===id); if (idx>=0) TICKETS[idx] = t;
    renderDetail(t);
  } catch(err){ showToast('Error: ' + err.message, 'error'); }
}
</script>
</body>
</html>
