setInterval(() => {
  location.reload(true);
}, 10000);

//CADA 10 SEGUNDOS PUTO