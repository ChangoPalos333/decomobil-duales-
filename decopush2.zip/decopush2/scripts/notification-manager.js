/**
 * =============================================
 * Notification Manager - DECOMOBIL
 * Gestión centralizada de notificaciones
 * =============================================
 */

class NotificationManager {
  constructor() {
    this.API_BASE = '../xampp_project/api';
    this.lastCheckTime = Math.floor(Date.now() / 1000);
    this.isPolling = false;
    this.pollInterval = null;
  }

  /**
   * Inicializar: registrar Service Worker y solicitar permisos
   */
  async init() {
    console.log('[NotifManager] Inicializando...');
    
    // Registrar Service Worker
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/service-worker.js', {
          scope: '/'
        });
        console.log('[NotifManager] Service Worker registrado:', registration);
      } catch (error) {
        console.warn('[NotifManager] Error registrando Service Worker:', error);
      }
    }

    // Solicitar permiso para notificaciones
    if ('Notification' in window && Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      console.log('[NotifManager] Permiso de notificaciones:', permission);
    }

    // Escuchar mensajes del Service Worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', (event) => {
        console.log('[NotifManager] Mensaje desde SW:', event.data);
        if (event.data.type === 'NOTIFICATION_CLICKED') {
          this.handleNotificationClick(event.data);
        }
      });
    }

    // Iniciar polling de notificaciones
    this.startPolling();
  }

  /**
   * Iniciar polling en segundo plano
   */
  startPolling() {
    if (this.isPolling) return;
    this.isPolling = true;
    console.log('[NotifManager] Iniciando polling de notificaciones');
    
    // Polling cada 5 segundos
    this.pollInterval = setInterval(() => {
      this.checkNotifications();
    }, 5000);
    
    // Primer chequeo inmediato
    this.checkNotifications();
  }

  /**
   * Detener polling
   */
  stopPolling() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    this.isPolling = false;
    console.log('[NotifManager] Polling detenido');
  }

  /**
   * Chequear notificaciones usando API unificado
   */
  async checkNotifications() {
    const token = sessionStorage.getItem('auth_token');
    if (!token) return;

    try {
      const res = await fetch(`${this.API_BASE}/notifications.php?since=${this.lastCheckTime}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (!res.ok) return;

      const json = await res.json();
      if (!json.success) return;

      // Actualizar último tiempo de chequeo
      if (json.timestamp) {
        this.lastCheckTime = json.timestamp;
      }

      // Procesar noticias
      if (Array.isArray(json.news)) {
        json.news.forEach(n => {
          this.showNotification(n.title || 'Nueva noticia', {
            body: n.description || '',
            icon: '/favicon.ico',
            tag: `news-${n.id}`,
            data: {
              type: 'news',
              newsId: n.id,
              newsTitle: n.title
            }
          });
        });
      }

      // Procesar actividad de chat
      if (Array.isArray(json.activity)) {
        const currentUser = JSON.parse(sessionStorage.getItem('user_session') || '{}');
        json.activity.forEach(a => {
          if (a.user_name !== currentUser.name && a.message) {
            this.showNotification(`💬 ${a.user_name}`, {
              body: a.message.substring(0, 100),
              icon: '/favicon.ico',
              tag: `chat-${a.ticket_id}`,
              data: {
                type: 'chat',
                ticketId: a.ticket_id,
                ticketTitle: `Ticket ${a.ticket_id}`
              }
            });
          }
        });
      }
    } catch (error) {
      console.error('[NotifManager] Error chequeando notificaciones:', error);
    }
  }

  /**
   * Mostrar notificación
   */
  showNotification(title, options = {}) {
    // Usar Notification API directamente
    if ('Notification' in window && Notification.permission === 'granted') {
      // Mostrar siempre, sin importar si la ventana está visible
      try {
        new Notification(title, {
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          requireInteraction: false,
          ...options
        });
      } catch (e) {
        console.error('[NotifManager] Error mostrando notificación:', e);
      }
    }
  }

  /**
   * Manejar clicks en notificaciones
   */
  handleNotificationClick(data) {
    console.log('[NotifManager] Notificación clickeada:', data);
    
    if (data.ticketId) {
      // Enviar a pestaña específica o abrir
      if (window.location.href.includes('home.php') || window.location.href.includes('admin.php')) {
        // Si estamos en home/admin, abrir el ticket
        if (typeof TicketChat !== 'undefined' && TicketChat.open) {
          TicketChat.open(data.ticketId, data.ticketTitle);
        }
      } else {
        window.location.href = '/src/home.php';
      }
    } else if (data.newsId) {
      // Mostrar panel de noticias
      if (window.location.href.includes('home.php')) {
        const panel = document.getElementById('newsPanel');
        if (panel) {
          panel.classList.add('open');
        }
      } else {
        window.location.href = '/src/home.php';
      }
    }
  }
}

// Inicializar cuando el DOM esté listo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.notificationManager = new NotificationManager();
    window.notificationManager.init();
  });
} else {
  window.notificationManager = new NotificationManager();
  window.notificationManager.init();
}
