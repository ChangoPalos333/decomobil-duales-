/* ══════════════════════════════════════════════════════════
   sw.js — Service Worker para notificaciones en background
   Coloca este archivo en la RAÍZ del proyecto (misma carpeta
   que home.php / admin.php).
   ══════════════════════════════════════════════════════════ */

const SW_VERSION = 'v1';

/* ── Instalación y activación inmediata ── */
self.addEventListener('install',  () => self.skipWaiting());
self.addEventListener('activate', e  => e.waitUntil(self.clients.claim()));

/* ══════════════════════════════════════════════════════════
   MENSAJES DESDE LAS PÁGINAS
   Las páginas envían mensajes con postMessage para que el SW
   pueda gestionar el polling y disparar notificaciones.
   ══════════════════════════════════════════════════════════ */
self.addEventListener('message', async (event) => {
  const { type, payload } = event.data || {};

  switch (type) {

    /* La página registra su token y última ID conocida */
    case 'INIT':
      swState.authToken    = payload.authToken || '';
      swState.apiBase      = payload.apiBase   || '';
      swState.currentUser  = payload.currentUser || null;
      swState.lastChatId   = Math.max(swState.lastChatId,  payload.lastChatId  || 0);
      swState.lastNewsId   = Math.max(swState.lastNewsId,  payload.lastNewsId  || 0);
      startPollingIfNeeded();
      break;

    /* La página actualiza el lastChatId (cuando ve mensajes en pantalla) */
    case 'UPDATE_LAST_CHAT_ID':
      swState.lastChatId = Math.max(swState.lastChatId, payload.lastChatId || 0);
      break;

    /* La página actualiza el lastNewsId */
    case 'UPDATE_LAST_NEWS_ID':
      swState.lastNewsId = Math.max(swState.lastNewsId, payload.lastNewsId || 0);
      break;

    /* La página cierra sesión */
    case 'LOGOUT':
      swState.authToken   = '';
      swState.polling     = false;
      break;
  }
});

/* ══════════════════════════════════════════════════════════
   ESTADO INTERNO DEL SW
   ══════════════════════════════════════════════════════════ */
const swState = {
  authToken:   '',
  apiBase:     '',
  currentUser: null,
  lastChatId:  0,
  lastNewsId:  0,
  polling:     false,
};

/* ══════════════════════════════════════════════════════════
   POLLING LOOP
   Corre aunque ninguna pestaña esté visible.
   ══════════════════════════════════════════════════════════ */
function startPollingIfNeeded() {
  if (swState.polling) return;
  swState.polling = true;
  pollLoop();
}

async function pollLoop() {
  while (swState.polling && swState.authToken) {
    try {
      await Promise.all([
        checkNewChatMessages(),
        checkNewNews(),
      ]);
    } catch (e) {
      /* red error → espera más */
      await sleep(5000);
      continue;
    }
    await sleep(4000); // intervalo de polling
  }
  swState.polling = false;
}

/* ── Revisar mensajes de chat nuevos ── */
async function checkNewChatMessages() {
  if (!swState.apiBase) return;
  const url = `${swState.apiBase}/activity.php?last_id=${swState.lastChatId}`;
  const res  = await fetchWithAuth(url);
  if (!res.ok) return;
  const json = await res.json();
  if (!json.success || !Array.isArray(json.data)) return;

  for (const m of json.data) {
    const mid = parseInt(m.id || 0);
    if (mid > swState.lastChatId) swState.lastChatId = mid;

    const isSystem = ['status','assign','resolve','create'].includes(m.activity_type);
    if (isSystem) continue;
    if (swState.currentUser && m.user_name === swState.currentUser.name) continue;

    /* ¿Está la página visible y ya mostrando este mensaje? */
    const alreadySeen = await isMessageVisible(mid);
    if (alreadySeen) continue;

    await showChatNotification(m);
  }
}

/* ── Revisar noticias nuevas ── */
async function checkNewNews() {
  if (!swState.apiBase) return;
  const url = `${swState.apiBase}/news.php`;
  const res  = await fetchWithAuth(url);
  if (!res.ok) return;
  const json = await res.json();

  // Soporta { data: [...] } o array directo
  const items = Array.isArray(json) ? json : (Array.isArray(json.data) ? json.data : []);
  if (!items.length) return;

  // Primer ciclo: inicializar lastNewsId sin notificar
  if (swState.lastNewsId === 0) {
    swState.lastNewsId = Math.max(...items.map(n => parseInt(n.id || 0)));
    broadcastLastNewsId(swState.lastNewsId);
    return;
  }

  for (const n of items) {
    const nid = parseInt(n.id || 0);
    if (nid <= swState.lastNewsId) continue;
    swState.lastNewsId = Math.max(swState.lastNewsId, nid);

    const alreadySeen = await isNewsVisible(nid);
    if (alreadySeen) continue;

    await showNewsNotification(n);
  }
  broadcastLastNewsId(swState.lastNewsId);
}

/* ══════════════════════════════════════════════════════════
   MOSTRAR NOTIFICACIONES
   ══════════════════════════════════════════════════════════ */
async function showChatNotification(m) {
  const text  = String(m.message || m.msg || '');
  const title = '💬 ' + (m.user_name || 'Mensaje nuevo');
  const body  = text.length > 90 ? text.slice(0, 87) + '…' : text;

  await self.registration.showNotification(title, {
    body,
    tag:     'chat-' + (m.ticket_id || m.id),
    icon:    '/favicon.ico',
    badge:   '/favicon.ico',
    vibrate: [150, 50, 150],
    data: {
      type:         'chat',
      ticketId:     m.ticket_id || m.id,
      ticketTitle:  m.ticket_title || m.title || '',
    }
  });
}

async function showNewsNotification(n) {
  const title = n.title || 'Nueva noticia';
  const body  = String(n.description || n.body || '');
  const short = body.length > 90 ? body.slice(0, 87) + '…' : body;

  await self.registration.showNotification('📰 ' + title, {
    body:    short,
    tag:     'news-' + n.id,
    icon:    '/favicon.ico',
    badge:   '/favicon.ico',
    vibrate: [100, 50, 100],
    data: {
      type:   'news',
      newsId: n.id,
    }
  });
}

/* ══════════════════════════════════════════════════════════
   CLICK EN NOTIFICACIÓN
   ══════════════════════════════════════════════════════════ */
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const data = event.notification.data || {};

  event.waitUntil((async () => {
    const allClients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });

    /* Buscar una pestaña ya abierta de la app */
    const appClient = allClients.find(c => c.url.includes('home.php') || c.url.includes('admin.php'));

    if (data.type === 'chat') {
      if (appClient) {
        await appClient.focus();
        appClient.postMessage({ type: 'OPEN_CHAT', ticketId: data.ticketId, ticketTitle: data.ticketTitle });
      } else {
        await self.clients.openWindow('admin.php');
      }
    } else if (data.type === 'news') {
      if (appClient) {
        await appClient.focus();
        appClient.postMessage({ type: 'OPEN_NEWS' });
      } else {
        await self.clients.openWindow('home.php');
      }
    }
  })());
});

/* ══════════════════════════════════════════════════════════
   HELPERS
   ══════════════════════════════════════════════════════════ */
function fetchWithAuth(url) {
  return fetch(url, {
    headers: { 'Authorization': 'Bearer ' + swState.authToken }
  });
}

/* Pregunta a las páginas abiertas si ya muestran este mensaje */
async function isMessageVisible(msgId) {
  const clients = await self.clients.matchAll({ type: 'window' });
  for (const c of clients) {
    const mc = new MessageChannel();
    const answer = await new Promise(resolve => {
      mc.port1.onmessage = e => resolve(e.data);
      c.postMessage({ type: 'IS_MSG_VISIBLE', msgId }, [mc.port2]);
      setTimeout(() => resolve(false), 300);
    });
    if (answer) return true;
  }
  return false;
}

async function isNewsVisible(newsId) {
  const clients = await self.clients.matchAll({ type: 'window' });
  for (const c of clients) {
    const mc = new MessageChannel();
    const answer = await new Promise(resolve => {
      mc.port1.onmessage = e => resolve(e.data);
      c.postMessage({ type: 'IS_NEWS_VISIBLE', newsId }, [mc.port2]);
      setTimeout(() => resolve(false), 300);
    });
    if (answer) return true;
  }
  return false;
}

function broadcastLastNewsId(id) {
  self.clients.matchAll({ type: 'window' }).then(clients => {
    clients.forEach(c => c.postMessage({ type: 'LAST_NEWS_ID', lastNewsId: id }));
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }