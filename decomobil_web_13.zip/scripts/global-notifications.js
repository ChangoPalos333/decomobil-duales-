(function () {
  if (window.__decomobilGlobalNotifications) return;
  window.__decomobilGlobalNotifications = true;

  const token = sessionStorage.getItem('auth_token');
  if (!token) return;

  const page = (location.pathname.split('/').pop() || '').toLowerCase();
  const apiBase = new URL('../xampp_project/api/', location.href).href.replace(/\/$/, '');
  const headers = () => ({ Authorization: 'Bearer ' + token });
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const originalTitle = document.title;
  let flashTimer = null;

  let currentUser = null;
  let lastTicketCreatedAt = null;
  let knownTicketIds = [];

  function getCurrentUser() {
    if (currentUser) return currentUser;
    try {
      currentUser = JSON.parse(sessionStorage.getItem('user_session') || 'null') || {};
    } catch (e) {
      currentUser = {};
    }
    return currentUser;
  }

  function shortText(value, max) {
    const text = String(value || '');
    return text.length > max ? text.slice(0, max - 3) + '...' : text;
  }

  function ensureContainer(id, side) {
    let container = document.getElementById(id);
    if (container) return container;
    container = document.createElement('div');
    container.id = id;
    const horizontal = side === 'left' ? 'left:18px;' : 'right:18px;';
    container.style.cssText =
      'position:fixed;' + horizontal +
      'bottom:18px;z-index:1000000;display:flex;flex-direction:column;gap:10px;' +
      'max-width:min(360px,calc(100vw - 36px));pointer-events:none;';
    document.body.appendChild(container);
    return container;
  }

  function makeNotice(containerId, side, titleText, bodyText, metaText, onClick) {
    const container = ensureContainer(containerId, side);
    const notice = document.createElement('button');
    notice.type = 'button';
    notice.style.cssText =
      'pointer-events:auto;text-align:left;border:1px solid rgba(15,82,186,.18);' +
      'border-left:4px solid #0F52BA;background:#fff;color:#111827;border-radius:10px;' +
      'padding:12px 14px;box-shadow:0 14px 35px rgba(15,23,42,.18);font-family:inherit;' +
      'cursor:pointer;max-width:100%;';
    notice.onclick = () => {
      notice.remove();
      onClick();
    };

    const title = document.createElement('div');
    title.style.cssText = 'font-size:13px;font-weight:800;margin-bottom:4px;color:#0F52BA;';
    title.textContent = titleText;

    const body = document.createElement('div');
    body.style.cssText = 'font-size:12.5px;line-height:1.45;color:#111827;white-space:normal;word-break:break-word;';
    body.textContent = bodyText;

    const meta = document.createElement('div');
    meta.style.cssText = 'font-size:10.5px;margin-top:7px;color:#6b7280;';
    meta.textContent = metaText;

    notice.append(title, body, meta);
    container.appendChild(notice);
    setTimeout(() => {
      notice.style.opacity = '0';
      notice.style.transform = 'translateY(8px)';
      notice.style.transition = 'all .25s ease';
      setTimeout(() => notice.remove(), 260);
    }, 7000);
  }

  function flashTitle(label) {
    if (flashTimer) clearInterval(flashTimer);
    let visible = false;
    document.title = label;
    flashTimer = setInterval(() => {
      visible = !visible;
      document.title = visible ? label : originalTitle;
    }, 900);
    setTimeout(() => {
      clearInterval(flashTimer);
      flashTimer = null;
      document.title = originalTitle;
    }, 12000);
  }

  function openChat(ticketId, ticketTitle) {
    const pending = JSON.stringify({ ticketId, ticketTitle });
    sessionStorage.setItem('pending_chat_ticket', pending);
    try {
      if (typeof TicketChat !== 'undefined' && TicketChat.open) {
        sessionStorage.removeItem('pending_chat_ticket');
        TicketChat.open(ticketId, ticketTitle);
        return;
      }
    } catch (e) {}
    location.href = new URL('home.php', location.href).href;
  }

  function openNews() {
    sessionStorage.setItem('pending_news_open', '1');
    const panel = document.getElementById('newsPanel');
    if (panel) {
      sessionStorage.removeItem('pending_news_open');
      panel.classList.add('open');
      return;
    }
    location.href = new URL('home.php', location.href).href;
  }

  function openTicket(ticketId, ticketTitle) {
    if (!ticketId) return;
    const detailPanel = document.getElementById('detailPanel');
    if (typeof openDetail === 'function') {
      try {
        openDetail(ticketId);
        if (detailPanel) detailPanel.classList.add('open');
        return;
      } catch (e) {}
    }
    location.href = new URL('home.php', location.href).href;
  }

  function setupNotificationPermissionButton() {
    if (typeof Notification === 'undefined') return;
    if (Notification.permission === 'granted') return;
    if (document.getElementById('notification-permission-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'notification-permission-btn';
    btn.type = 'button';
    btn.textContent = Notification.permission === 'denied'
      ? 'Notificaciones bloqueadas'
      : 'Activar notificaciones';
    btn.style.cssText =
      'position:fixed;right:18px;bottom:84px;z-index:1000001;border:none;border-radius:10px;' +
      'background:#0F52BA;color:#fff;padding:10px 13px;font:700 12px inherit;cursor:pointer;' +
      'box-shadow:0 12px 30px rgba(15,23,42,.22);';

    btn.onclick = async () => {
      if (Notification.permission === 'denied') {
        alert('El navegador tiene bloqueadas las notificaciones para este sitio. Activalas en permisos del sitio de localhost y recarga la pagina.');
        return;
      }

      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        btn.remove();
        notifySystem('Notificaciones activas', {
          body: 'Decomobil ya puede avisarte aunque estes en otra pestana o ventana.',
          tag: 'decomobil-test',
          icon: '/favicon.ico'
        });
      } else {
        btn.textContent = 'Notificaciones bloqueadas';
      }
    };

    document.body.appendChild(btn);
  }

  async function getNotificationRegistration() {
    if (!('serviceWorker' in navigator)) return null;
    try {
      const registration = await navigator.serviceWorker.register('../global-notifications-sw.js', { scope: '../' });
      await navigator.serviceWorker.ready;
      return registration;
    } catch (e) {
      return null;
    }
  }

  async function notifySystem(title, options) {
    if (typeof Notification === 'undefined') return false;
    if (Notification.permission !== 'granted') {
      return false;
    }

    try {
      const registration = await getNotificationRegistration();
      if (registration && registration.showNotification) {
        await registration.showNotification(title, options);
        return true;
      }
    } catch (e) {}

    try {
      const notification = new Notification(title, options);
      notification.onclick = () => {
        window.focus();
        notification.close();
        if (options?.data?.type === 'chat') openChat(options.data.ticketId, options.data.ticketTitle);
        if (options?.data?.type === 'news') openNews();
        if (options?.data?.type === 'ticket') openTicket(options.data.ticketId, options.data.ticketTitle);
      };
      setTimeout(() => notification.close(), 6000);
      return true;
    } catch (e) {}
    return false;
  }
  window.DecomobilNotifySystem = notifySystem;

  function handlePendingActions() {
    const pendingChat = sessionStorage.getItem('pending_chat_ticket');
    if (pendingChat) {
      try {
        const data = JSON.parse(pendingChat);
        if (data.ticketId && typeof TicketChat !== 'undefined' && TicketChat.open) {
          sessionStorage.removeItem('pending_chat_ticket');
          TicketChat.open(data.ticketId, data.ticketTitle || data.ticketId);
        }
      } catch (e) {
        sessionStorage.removeItem('pending_chat_ticket');
      }
    }

    if (sessionStorage.getItem('pending_news_open') === '1') {
      const panel = document.getElementById('newsPanel');
      if (panel) {
        sessionStorage.removeItem('pending_news_open');
        panel.classList.add('open');
      }
    }
  }

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', event => {
      const payload = event.data || {};
      if (payload.type !== 'notification-click') return;
      const data = payload.data || {};
      if (data.type === 'chat') openChat(data.ticketId, data.ticketTitle || data.ticketId);
      if (data.type === 'news') openNews();
      if (data.type === 'ticket') openTicket(data.ticketId, data.ticketTitle || data.ticketId);
    });
  }

  function refreshTicketPages() {
    if (page === 'home.php' && typeof renderHome === 'function') {
      renderHome();
      return;
    }
    if (page === 'admin.php' && typeof reloadData === 'function') {
      reloadData();
      return;
    }
  }

  function showTicketNotification(ticket) {
    if (!ticket) return;
    const creator = ticket.creator_name || 'Un usuario';
    const titleText = 'Nuevo ticket de ' + creator;
    const bodyText = shortText(ticket.title || ticket.description || 'Sin título', 110);
    const metaText = ticket.id ? `${ticket.id} · ${ticket.priority || 'Sin prioridad'}` : '';

    makeNotice(
      'global-ticket-notice-container',
      'left',
      titleText,
      bodyText,
      metaText,
      () => openTicket(ticket.id, ticket.title)
    );

    if (!document.hasFocus()) {
      flashTitle('Nuevo ticket - Decomobil');
    }

    notifySystem(titleText, {
      body: bodyText,
      tag: 'ticket-' + (ticket.id || Math.random()),
      icon: '/favicon.ico',
      data: { type: 'ticket', ticketId: ticket.id, ticketTitle: ticket.title }
    });
  }

  async function startTicketWatcher() {
    const user = getCurrentUser();
    if (!user || !['agent', 'admin'].includes(user.role)) return;

    async function pollTickets() {
      try {
        const res = await fetch(`${apiBase}/tickets.php?sort=created_at&dir=DESC&limit=10`, { headers: headers() });
        const json = await res.json();
        if (json.success && Array.isArray(json.data)) {
          const tickets = json.data;
          if (lastTicketCreatedAt === null) {
            knownTicketIds = tickets.map(t => t.id);
            if (tickets.length) lastTicketCreatedAt = tickets[0].created_at || '';
          } else {
            const newTickets = tickets.filter(t => !knownTicketIds.includes(t.id));
            if (newTickets.length) {
              newTickets.reverse().forEach(ticket => {
                if (ticket.created_by !== user.id) {
                  showTicketNotification(ticket);
                }
              });
              refreshTicketPages();
            }
            knownTicketIds = tickets.map(t => t.id);
            if (tickets.length) lastTicketCreatedAt = tickets[0].created_at || lastTicketCreatedAt;
          }
        }
      } catch (e) {
        // Ignore polling errors and retry later
      }
      setTimeout(pollTickets, 8000);
    }

    pollTickets();
  }

  function showChatNotification(message) {
    const user = getCurrentUser();
    if (message.user_name === user.name) return;

    const chatPanelEl = document.getElementById('dc-chat-panel');
    if (chatPanelEl?.classList.contains('open')) return;

    const ticketId = message.ticket_id || message.ticket || message.id;
    const ticketTitle = message.ticket_title || message.title || ticketId;
    makeNotice(
      'global-chat-notice-container',
      'right',
      'Nuevo mensaje de ' + (message.user_name || 'Usuario'),
      shortText(message.message || message.msg || '', 120),
      ticketTitle ? `${ticketId} - ${ticketTitle}` : String(ticketId || ''),
      () => openChat(ticketId, ticketTitle)
    );
    if (!document.hasFocus()) {
      flashTitle('Nuevo mensaje - Decomobil');
    }

    notifySystem('Nuevo mensaje de ' + (message.user_name || 'Usuario'), {
      body: shortText(message.message || message.msg || '', 90),
      tag: 'chat-' + ticketId,
      icon: '/favicon.ico',
      data: { type: 'chat', ticketId, ticketTitle, url: new URL('home.php', location.href).href }
    });
  }

  function showNewsNotification(news) {
    const panel = document.getElementById('newsPanel');
    if (!document.hidden && panel && panel.classList.contains('open')) return;

    makeNotice(
      'global-news-notice-container',
      'left',
      'Nueva noticia',
      news.title || 'Comunicado interno',
      shortText(news.description || '', 110),
      openNews
    );
    if (!document.hasFocus()) {
      flashTitle('Nueva noticia - Decomobil');
    }

    if (document.hidden) {
      notifySystem(news.title || 'Nueva noticia', {
        body: shortText(news.description || '', 90),
        tag: 'news-' + news.id,
        icon: '/favicon.ico',
        data: { type: 'news', newsId: news.id, url: new URL('home.php', location.href).href }
      });
    }
  }

  async function startChatWatcher() {
    let lastId = 0;
    try {
      const init = await fetch(`${apiBase}/activity.php?last_id=0&init=1`, { headers: headers() });
      const json = await init.json();
      if (json.success) lastId = parseInt(json.last_id || 0);
    } catch (e) {
      await sleep(3000);
      startChatWatcher();
      return;
    }

    async function poll() {
      try {
        const res = await fetch(`${apiBase}/activity.php?last_id=${lastId}`, { headers: headers() });
        const json = await res.json();
        if (json.success && Array.isArray(json.data)) {
          json.data.forEach(item => {
            const type = item.activity_type;
            const isSystem = ['status', 'assign', 'resolve', 'create'].includes(type);
            const mid = parseInt(item.id || 0);
            if (!isSystem) showChatNotification(item);
            if (mid > lastId) lastId = mid;
          });
          if (json.last_id) lastId = Math.max(lastId, parseInt(json.last_id || 0));
        }
      } catch (e) {
        await sleep(2000);
      }
      setTimeout(poll, 1500);
    }

    poll();
  }

  async function startNewsWatcher() {
    let knownIds = null;

    async function poll() {
      try {
        const res = await fetch(`${apiBase}/news.php`, { headers: headers() });
        const json = await res.json();
        const news = json.data || [];
        const ids = news.map(item => item.id);
        if (Array.isArray(knownIds)) {
          news
            .filter(item => !knownIds.includes(item.id))
            .reverse()
            .forEach(showNewsNotification);
        }
        knownIds = ids;
      } catch (e) {}
      setTimeout(poll, 8000);
    }

    poll();
  }

  window.addEventListener('DOMContentLoaded', () => {
    setupNotificationPermissionButton();
    handlePendingActions();
    const pageHasLocalNewsWatcher = page === 'home.php';
    const pageHasLocalChatWatcher = page === 'home.php' || page === 'admin.php';
    const hasLocalChatWatcher = pageHasLocalChatWatcher && typeof TicketChat !== 'undefined' && typeof TicketChat.startGlobalChatWatcher === 'function';
    if (!hasLocalChatWatcher) startChatWatcher();
    if (!pageHasLocalNewsWatcher) startNewsWatcher();
    startTicketWatcher();
  });
})();
