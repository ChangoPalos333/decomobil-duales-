-- =============================================
-- DECOMOBIL - Sistema de Tickets de Soporte
-- Base de datos para phpMyAdmin/MySQL (XAMPP)
-- =============================================
-- 
-- DESCRIPCION GENERAL:
-- Este archivo SQL crea la estructura completa de la base de datos
-- para el sistema de gestion de tickets DECOMOBIL.
-- 
-- TABLAS INCLUIDAS:
-- 1. users           - Usuarios del sistema (admins, agentes, usuarios)
-- 2. tickets         - Tickets de soporte con prioridad y estado
-- 3. ticket_activity - Historial de cambios y comentarios en tickets
-- 4. sessions        - Control de sesiones activas de usuarios
--
-- INSTRUCCIONES DE USO:
-- 1. Abrir phpMyAdmin en http://localhost/phpmyadmin
-- 2. Ir a la pestana "Importar"
-- 3. Seleccionar este archivo y ejecutar
--
-- REQUISITOS:
-- - MySQL 5.7+ o MariaDB 10.2+
-- - Motor InnoDB para soporte de claves foraneas
-- =============================================


-- =============================================
-- PASO 1: CREAR LA BASE DE DATOS
-- =============================================
-- Creamos la base de datos con codificacion UTF8MB4
-- que soporta caracteres especiales y emojis

CREATE DATABASE IF NOT EXISTS decomobil_db 
CHARACTER SET utf8mb4                    -- Codificacion de caracteres completa
COLLATE utf8mb4_unicode_ci;              -- Comparacion sin distincion de mayusculas

-- Seleccionamos la base de datos para trabajar
USE decomobil_db;


-- =============================================
-- PASO 2: TABLA DE USUARIOS (users)
-- =============================================
-- Esta tabla almacena todos los usuarios del sistema.
-- Los usuarios pueden tener 3 roles:
--   - admin: Acceso total al sistema
--   - agent: Puede gestionar tickets asignados
--   - user:  Solo puede crear tickets y ver los propios
--
-- CAMPOS:
-- id         - Identificador unico auto-incremental
-- name       - Nombre completo del usuario
-- email      - Correo electronico (unico, para login)
-- password   - Contrasena hasheada con bcrypt
-- role       - Rol del usuario (admin/agent/user)
-- dept       - Departamento al que pertenece
-- avatar     - Color hexadecimal para el avatar
-- active     - 1=activo, 0=desactivado (soft delete)
-- created_at - Fecha de creacion de la cuenta
-- updated_at - Fecha de ultima modificacion

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,                           -- Llave primaria auto-incremental
    name VARCHAR(100) NOT NULL,                                  -- Nombre obligatorio, max 100 caracteres
    email VARCHAR(100) NOT NULL UNIQUE,                          -- Email unico para evitar duplicados
    password VARCHAR(255) NOT NULL,                              -- Hash bcrypt (siempre 60 chars, dejamos 255 por si cambia)
    role ENUM('admin', 'agent', 'user') DEFAULT 'user',          -- Solo estos 3 valores son permitidos
    dept VARCHAR(50) DEFAULT NULL,                               -- Departamento opcional
    avatar VARCHAR(20) DEFAULT '#0F52BA',                        -- Color por defecto (azul)
    active TINYINT(1) DEFAULT 1,                                 -- 1=activo, 0=inactivo
    created_at DATE DEFAULT (CURRENT_DATE),                      -- Fecha de creacion automatica
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP               -- Se actualiza automaticamente
               ON UPDATE CURRENT_TIMESTAMP                       -- cada vez que se modifica el registro
) ENGINE=InnoDB;                                                 -- Motor InnoDB para integridad referencial


-- =============================================
-- PASO 3: TABLA DE TICKETS (tickets)
-- =============================================
-- Esta tabla almacena los tickets de soporte.
-- Cada ticket tiene un ID legible (TK-001, TK-002, etc.)
--
-- ESTADOS POSIBLES (status):
--   - Abierto:      Ticket nuevo sin atender
--   - En Progreso:  Ticket siendo trabajado
--   - En Revision:  Esperando validacion
--   - Pendiente:    En espera de informacion
--   - Resuelto:     Ticket completado
--
-- PRIORIDADES (priority):
--   - Critica: Atencion inmediata requerida
--   - Alta:    Importante, resolver pronto
--   - Media:   Normal, sin urgencia
--   - Baja:    Puede esperar
--
-- CAMPOS:
-- id          - ID legible del ticket (TK-001)
-- title       - Titulo descriptivo del problema
-- description - Descripcion detallada del ticket
-- priority    - Nivel de urgencia
-- status      - Estado actual del ticket
-- category    - Categoria (TI, CONT, RRHH, etc.)
-- dept        - Departamento que reporta
-- assignee_id - Usuario asignado para resolver
-- created_by  - Usuario que creo el ticket
-- due_date    - Fecha limite de resolucion
-- resolved_at - Fecha/hora de resolucion
-- created_at  - Fecha de creacion
-- updated_at  - Ultima modificacion

CREATE TABLE IF NOT EXISTS tickets (
    id VARCHAR(20) PRIMARY KEY,                                  -- ID legible como llave primaria
    title VARCHAR(255) NOT NULL,                                 -- Titulo obligatorio
    description TEXT,                                            -- Descripcion puede ser larga
    priority ENUM('Critica', 'Alta', 'Media', 'Baja')           -- Solo estos valores
             DEFAULT 'Media',                                    -- Por defecto: Media
    status ENUM('Abierto', 'En Progreso', 'En Revision',        -- Estados del ticket
                'Pendiente', 'Resuelto') 
           DEFAULT 'Abierto',                                    -- Por defecto: Abierto
    category VARCHAR(50) DEFAULT 'TI',                           -- Categoria por defecto: TI
    dept VARCHAR(50) DEFAULT NULL,                               -- Departamento opcional
    assignee_id INT DEFAULT NULL,                                -- Puede no tener asignado
    created_by INT NOT NULL,                                     -- Obligatorio saber quien lo creo
    due_date DATE DEFAULT NULL,                                  -- Fecha limite opcional
    resolved_at DATETIME DEFAULT NULL,                           -- Se llena al resolver
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,              -- Automatico al crear
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP               -- Automatico al modificar
               ON UPDATE CURRENT_TIMESTAMP,
    
    -- CLAVES FORANEAS --
    -- Si se elimina el usuario asignado, el campo queda NULL
    FOREIGN KEY (assignee_id) REFERENCES users(id) ON DELETE SET NULL,
    -- Si se elimina el creador, se eliminan sus tickets (CASCADE)
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;


-- =============================================
-- PASO 4: TABLA DE ACTIVIDAD (ticket_activity)
-- =============================================
-- Esta tabla registra todo el historial de un ticket:
-- comentarios, cambios de estado, asignaciones, etc.
--
-- TIPOS DE ACTIVIDAD (activity_type):
--   - create:  Ticket fue creado
--   - comment: Alguien agrego un comentario
--   - status:  Se cambio el estado
--   - assign:  Se asigno/reasigno el ticket
--   - resolve: Se marco como resuelto
--
-- CAMPOS:
-- id            - ID auto-incremental
-- ticket_id     - Referencia al ticket
-- user_name     - Nombre del usuario que hizo la accion
-- activity_type - Tipo de actividad
-- message       - Descripcion o comentario
-- created_at    - Cuando ocurrio

CREATE TABLE IF NOT EXISTS ticket_activity (
    id INT AUTO_INCREMENT PRIMARY KEY,                           -- ID unico de la actividad
    ticket_id VARCHAR(20) NOT NULL,                              -- ID del ticket relacionado
    user_name VARCHAR(100) NOT NULL,                             -- Quien realizo la accion
    activity_type ENUM('create', 'comment', 'status',            -- Tipos permitidos
                       'assign', 'resolve') 
                  DEFAULT 'comment',                             -- Por defecto: comentario
    message TEXT,                                                -- Detalle de la actividad
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,              -- Cuando ocurrio
    
    -- CLAVE FORANEA --
    -- Si se elimina el ticket, se elimina toda su actividad
    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB;


-- =============================================
-- PASO 5: TABLA DE SESIONES (sessions)
-- =============================================
-- Esta tabla controla las sesiones activas de los usuarios.
-- Cada vez que un usuario inicia sesion, se crea un token unico.
-- El token expira despues de 24 horas.
--
-- CAMPOS:
-- id            - ID auto-incremental
-- user_id       - Usuario dueno de la sesion
-- session_token - Token unico generado al login
-- expires_at    - Cuando expira la sesion
-- created_at    - Cuando se creo la sesion

CREATE TABLE IF NOT EXISTS sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,                           -- ID de la sesion
    user_id INT NOT NULL,                                        -- Usuario de la sesion
    session_token VARCHAR(255) NOT NULL UNIQUE,                  -- Token unico de 64 caracteres hex
    expires_at DATETIME NOT NULL,                                -- Fecha/hora de expiracion
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,              -- Cuando se creo
    
    -- CLAVE FORANEA --
    -- Si se elimina el usuario, se eliminan sus sesiones
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;


-- =============================================
-- PASO 6: DATOS INICIALES - USUARIOS DE PRUEBA
-- =============================================
-- Insertamos usuarios de ejemplo para poder probar el sistema.
-- IMPORTANTE: La contrasena hasheada corresponde a "password"
-- Este hash fue generado con password_hash('password', PASSWORD_DEFAULT)
-- 
-- USUARIOS CREADOS:
-- 1. admin@empresa.com    - Administrador (acceso total)
-- 2. ana@empresa.com      - Agente de TI
-- 3. carlos@empresa.com   - Agente de TI
-- 4. maria@empresa.com    - Usuario de Contabilidad
-- 5. pedro@empresa.com    - Usuario de Ventas
--
-- PARA PRODUCCION: Cambiar estas contrasenas!

INSERT INTO users (name, email, password, role, dept, avatar, active, created_at) VALUES

-- Usuario administrador principal
('Administrador General',                                        -- Nombre completo
 'admin@empresa.com',                                            -- Email para login
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- Hash de "password"
 'admin',                                                        -- Rol: administrador
 'Direccion',                                                    -- Departamento
 '#0F52BA',                                                      -- Avatar azul
 1,                                                              -- Activo
 '2025-01-01'),                                                  -- Fecha de creacion

-- Agente de soporte tecnico 1
('Ana Garcia',
 'ana@empresa.com',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'agent',                                                        -- Rol: agente
 'TI',                                                           -- Departamento TI
 '#15803D',                                                      -- Avatar verde
 1,
 '2025-01-15'),

-- Agente de soporte tecnico 2
('Carlos Lopez',
 'carlos@empresa.com',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'agent',
 'TI',
 '#B45309',                                                      -- Avatar naranja
 1,
 '2025-01-15'),

-- Usuario normal de Contabilidad
('Maria Torres',
 'maria@empresa.com',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'user',                                                         -- Rol: usuario normal
 'Contabilidad',
 '#6D28D9',                                                      -- Avatar morado
 1,
 '2025-02-01'),

-- Usuario normal de Ventas
('Pedro Ruiz',
 'pedro@empresa.com',
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
 'user',
 'Ventas',
 '#D93025',                                                      -- Avatar rojo
 1,
 '2025-02-10');


-- =============================================
-- PASO 7: DATOS INICIALES - TICKETS DE EJEMPLO
-- =============================================
-- Insertamos tickets de ejemplo que muestran diferentes
-- estados, prioridades y escenarios comunes.

INSERT INTO tickets (id, title, description, priority, status, category, dept, assignee_id, created_by, due_date) VALUES

-- Ticket critico en progreso (VPN caida)
('TK-001',                                                       -- ID del ticket
 'Falla en conexion VPN del area de ventas',                     -- Titulo descriptivo
 'Los usuarios del area de ventas no pueden conectarse a la VPN corporativa desde las 8am. Afecta a 7 personas.',
 'Critica',                                                      -- Prioridad maxima
 'En Progreso',                                                  -- Ya se esta trabajando
 'TI',                                                           -- Categoria
 'Ventas',                                                       -- Departamento afectado
 2,                                                              -- Asignado a Ana (ID 2)
 5,                                                              -- Creado por Pedro (ID 5)
 DATE_ADD(CURDATE(), INTERVAL 3 DAY)),                           -- Vence en 3 dias

-- Ticket de solicitud de equipo
('TK-002',
 'Solicitud de equipo: monitor adicional para diseno',
 'El area de diseno necesita un monitor adicional para mejorar la productividad.',
 'Media',                                                        -- Prioridad normal
 'Abierto',                                                      -- Sin atender aun
 'TI',
 'Produccion',
 NULL,                                                           -- Sin asignar
 4,                                                              -- Creado por Maria
 DATE_ADD(CURDATE(), INTERVAL 7 DAY)),

-- Ticket de permisos en revision
('TK-003',
 'Actualizacion de permisos en sistema ERP',
 'Se requiere actualizar permisos del modulo de compras para usuario promovido.',
 'Alta',
 'En Revision',                                                  -- Esperando validacion
 'TI',
 'Administracion',
 3,                                                              -- Asignado a Carlos
 1,                                                              -- Creado por Admin
 DATE_ADD(CURDATE(), INTERVAL 1 DAY)),                           -- Urgente: vence manana

-- Ticket de error contable
('TK-004',
 'Error en nomina - calculo de horas extra',
 'Error en calculo de horas extra para turno nocturno. Afecta a 12 colaboradores.',
 'Alta',
 'Abierto',
 'CONT',                                                         -- Categoria: Contabilidad
 'Finanzas',
 2,
 4,
 DATE_ADD(CURDATE(), INTERVAL 1 DAY)),

-- Ticket de capacitacion
('TK-005',
 'Solicitud capacitacion: Excel avanzado',
 'Equipo de logistica solicita capacitacion de Excel avanzado para 8 personas.',
 'Baja',                                                         -- Prioridad baja
 'Pendiente',                                                    -- Esperando informacion
 'TI',
 'Logistica',
 NULL,
 5,
 DATE_ADD(CURDATE(), INTERVAL 14 DAY)),                          -- 2 semanas

-- Ticket resuelto (ejemplo de historial)
('TK-006',
 'Falla impresora piso 3',
 'Impresora HP del piso 3 no responde. Necesita revision urgente.',
 'Media',
 'Resuelto',                                                     -- Ya resuelto
 'TI',
 'Administracion',
 3,
 1,
 CURDATE());                                                     -- Vencia hoy


-- =============================================
-- PASO 8: DATOS INICIALES - ACTIVIDAD DE TICKETS
-- =============================================
-- Insertamos el historial de actividad para los tickets de ejemplo.
-- Esto muestra como se ve el timeline de un ticket.

INSERT INTO ticket_activity (ticket_id, user_name, activity_type, message) VALUES

-- Actividad del ticket TK-001
('TK-001', 'Sistema', 'create', 'Ticket creado'),                -- Creacion automatica
('TK-001', 'Ana Garcia', 'comment', 'Revisando configuracion de VPN'), -- Comentario del agente

-- Actividad del ticket TK-002
('TK-002', 'Sistema', 'create', 'Ticket creado'),

-- Actividad del ticket TK-003
('TK-003', 'Sistema', 'create', 'Ticket creado'),
('TK-003', 'Carlos Lopez', 'comment', 'Revisando con admin del ERP.'),

-- Actividad del ticket TK-004
('TK-004', 'Sistema', 'create', 'Ticket creado'),

-- Actividad del ticket TK-005
('TK-005', 'Sistema', 'create', 'Ticket creado'),

-- Actividad del ticket TK-006 (resuelto)
('TK-006', 'Sistema', 'create', 'Ticket creado'),
('TK-006', 'Carlos Lopez', 'resolve', 'Problema resuelto - se reemplazo toner'); -- Resolucion


-- =============================================
-- PASO 9: INDICES PARA OPTIMIZACION
-- =============================================
-- Los indices mejoran la velocidad de las consultas frecuentes.
-- Creamos indices en los campos que mas se usan para filtrar.
--
-- NOTA: Los indices ocupan espacio adicional pero hacen
-- las consultas mucho mas rapidas, especialmente con
-- miles de registros.

-- Indice para filtrar tickets por estado (Abierto, Resuelto, etc.)
CREATE INDEX idx_tickets_status ON tickets(status);

-- Indice para filtrar tickets por prioridad (Critica, Alta, etc.)
CREATE INDEX idx_tickets_priority ON tickets(priority);

-- Indice para buscar tickets asignados a un usuario
CREATE INDEX idx_tickets_assignee ON tickets(assignee_id);

-- Indice para buscar tickets creados por un usuario
CREATE INDEX idx_tickets_created_by ON tickets(created_by);

-- Indice para buscar actividad de un ticket especifico
CREATE INDEX idx_activity_ticket ON ticket_activity(ticket_id);


-- =============================================
-- NOTAS FINALES
-- =============================================
-- 
-- CREDENCIALES POR DEFECTO:
-- Email: admin@empresa.com
-- Password: password
--
-- PARA PRODUCCION:
-- 1. Cambiar todas las contrasenas de los usuarios
-- 2. Eliminar los usuarios y tickets de ejemplo
-- 3. Configurar backups automaticos de la base de datos
-- 4. Considerar agregar SSL/TLS para conexiones
--
-- PARA SOPORTE:
-- Si tienes problemas, verifica:
-- 1. Que MySQL/MariaDB este corriendo en XAMPP
-- 2. Que el usuario root tenga permisos suficientes
-- 3. Que la codificacion sea utf8mb4
-- =============================================
