<?php
require_once __DIR__ . '/../xampp_project/config/database.php';

$db = getDB();

$password = 'admin123';
$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $db->prepare("UPDATE users SET password = ? WHERE email = ?");
$stmt->execute([$hash, 'carlosA@empresa.com']);

echo "Password hashed and updated: $hash\n";

//! esta shit es para hashear o encriptar las contraseñas por que aun no hago los tickets